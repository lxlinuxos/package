#!/usr/bin/env python

import Core

c=Core.Core.get_core()




