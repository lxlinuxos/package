<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es">
<context>
    <name>main</name>
    <message>
        <location filename="../libs/utils_graphicsview.py" line="842"/>
        <source>Select pen width:</source>
        <translation>Seleccione el ancho de la pluma:</translation>
    </message>
    <message>
        <location filename="../libs/utils_dialogs.py" line="565"/>
        <source>Solid</source>
        <translation>Lineas solidas</translation>
    </message>
    <message>
        <location filename="../libs/utils_dialogs.py" line="572"/>
        <source>Dash</source>
        <translation>Guiones</translation>
    </message>
    <message>
        <location filename="../libs/utils_dialogs.py" line="579"/>
        <source>Dot</source>
        <translation>Puntos</translation>
    </message>
    <message>
        <location filename="../libs/utils_dialogs.py" line="586"/>
        <source>Dash Dot</source>
        <translation>Guiones Puntos</translation>
    </message>
    <message>
        <location filename="../libs/utils_dialogs.py" line="593"/>
        <source>Dash Dot Dot</source>
        <translation>Guiones Puntos Puntos</translation>
    </message>
    <message>
        <location filename="../libs/utils_graphicsview.py" line="786"/>
        <source>Select color</source>
        <translation>Elige un color</translation>
    </message>
    <message>
        <location filename="../libs/main.py" line="696"/>
        <source>Quit</source>
        <translation>Salir</translation>
    </message>
    <message>
        <location filename="../libs/utils_dialogs.py" line="183"/>
        <source>Open...</source>
        <translation>Abrir...</translation>
    </message>
    <message>
        <location filename="../libs/utils_dialogs.py" line="223"/>
        <source>Save as...</source>
        <translation>Guardar como...</translation>
    </message>
    <message>
        <location filename="../libs/utils_dialogs.py" line="191"/>
        <source>Reload</source>
        <translation>Recargar</translation>
    </message>
    <message>
        <location filename="../libs/utils_dialogs.py" line="199"/>
        <source>Next file</source>
        <translation>Siguiente archivo</translation>
    </message>
    <message>
        <location filename="../libs/utils_dialogs.py" line="264"/>
        <source>Configure</source>
        <translation>Configurar</translation>
    </message>
    <message>
        <location filename="../libs/utils_dialogs.py" line="272"/>
        <source>Minimize</source>
        <translation>Minimizar</translation>
    </message>
    <message>
        <location filename="../libs/main.py" line="703"/>
        <source>Help</source>
        <translation>Ayuda</translation>
    </message>
    <message>
        <location filename="../libs/utils_about.py" line="89"/>
        <source>About</source>
        <translation>Acerca de</translation>
    </message>
    <message>
        <location filename="../libs/utils_dialogs.py" line="391"/>
        <source>Lock instruments</source>
        <translation>Bloquear instrumentos</translation>
    </message>
    <message>
        <location filename="../libs/utils_dialogs.py" line="430"/>
        <source>Show false cursor</source>
        <translation>Mostrar cursor falso</translation>
    </message>
    <message>
        <location filename="../libs/utils_dialogs.py" line="289"/>
        <source>New screenshot</source>
        <translation>Nueva captura de pantalla</translation>
    </message>
    <message>
        <location filename="../libs/utils_dialogs.py" line="303"/>
        <source>White page</source>
        <translation>Página en blanco</translation>
    </message>
    <message>
        <location filename="../libs/utils_dialogs.py" line="310"/>
        <source>Dotted paper</source>
        <translation>Papel punteado</translation>
    </message>
    <message>
        <location filename="../libs/utils_dialogs.py" line="317"/>
        <source>Grid</source>
        <translation>Cuadrícula</translation>
    </message>
    <message>
        <location filename="../libs/utils_dialogs.py" line="324"/>
        <source>Choose background</source>
        <translation>Escoge el fondo</translation>
    </message>
    <message>
        <location filename="../libs/utils_dialogs.py" line="333"/>
        <source>Ruler</source>
        <translation>Regla</translation>
    </message>
    <message>
        <location filename="../libs/utils_dialogs.py" line="352"/>
        <source>Square</source>
        <translation>Escuadra</translation>
    </message>
    <message>
        <location filename="../libs/utils_dialogs.py" line="371"/>
        <source>Protractor</source>
        <translation>Transportadora</translation>
    </message>
    <message>
        <location filename="../libs/utils_dialogs.py" line="381"/>
        <source>Compass</source>
        <translation>Compás</translation>
    </message>
    <message>
        <location filename="../libs/utils_dialogs.py" line="704"/>
        <source>Select</source>
        <translation>Seleccionar</translation>
    </message>
    <message>
        <location filename="../libs/utils_dialogs.py" line="450"/>
        <source>Line</source>
        <translation>Linea</translation>
    </message>
    <message>
        <location filename="../libs/utils_dialogs.py" line="457"/>
        <source>Curve</source>
        <translation>Dibujar</translation>
    </message>
    <message>
        <location filename="../libs/utils_dialogs.py" line="464"/>
        <source>Highlighter</source>
        <translation>Marcatextos</translation>
    </message>
    <message>
        <location filename="../libs/utils_dialogs.py" line="471"/>
        <source>Add text</source>
        <translation>Añadir texto</translation>
    </message>
    <message>
        <location filename="../libs/utils_dialogs.py" line="478"/>
        <source>Add point</source>
        <translation>Agregar un punto</translation>
    </message>
    <message>
        <location filename="../libs/utils_dialogs.py" line="485"/>
        <source>Add pixmap</source>
        <translation>Agregar una imagen</translation>
    </message>
    <message>
        <location filename="../libs/utils_dialogs.py" line="74"/>
        <source>Color</source>
        <translation>Color</translation>
    </message>
    <message>
        <location filename="../libs/utils_dialogs.py" line="769"/>
        <source>Styles</source>
        <translation>Estilos</translation>
    </message>
    <message>
        <location filename="../libs/utils_dialogs.py" line="68"/>
        <source>Font</source>
        <translation>Fuente</translation>
    </message>
    <message>
        <location filename="../libs/utils_dialogs.py" line="520"/>
        <source>Delete selected object</source>
        <translation>Eliminar objeto seleccionado</translation>
    </message>
    <message>
        <location filename="../libs/utils_dialogs.py" line="527"/>
        <source>Erase all</source>
        <translation>Borrar todo</translation>
    </message>
    <message>
        <location filename="../libs/utils_instruments.py" line="277"/>
        <source>Point name:</source>
        <translation>Nombre del punto:</translation>
    </message>
    <message>
        <location filename="../libs/utils_config.py" line="410"/>
        <source>Configuration</source>
        <translation>Configuración</translation>
    </message>
    <message>
        <location filename="../libs/utils_config.py" line="447"/>
        <source>Other</source>
        <translation>Otros</translation>
    </message>
    <message>
        <location filename="../libs/utils_config.py" line="115"/>
        <source>&lt;P&gt;&lt;/P&gt;&lt;P ALIGN=LEFT&gt;Here you can select on which screen you will to work.&lt;/P&gt;</source>
        <translation>&lt;P&gt;&lt;/P&gt;&lt;P ALIGN=LEFT&gt;Aquí puede elegir en qué pantalla trabajar.&lt;/P&gt;</translation>
    </message>
    <message>
        <location filename="../libs/utils_config.py" line="62"/>
        <source>Screen usage mode</source>
        <translation>Modo de uso de pantalla</translation>
    </message>
    <message>
        <location filename="../libs/utils_config.py" line="66"/>
        <source>All space</source>
        <translation>Todo el espacio</translation>
    </message>
    <message>
        <location filename="../libs/utils_config.py" line="68"/>
        <source>Full screen</source>
        <translation>Pantalla completa</translation>
    </message>
    <message>
        <location filename="../libs/utils_config.py" line="96"/>
        <source>Screen number</source>
        <translation>Número de Pantalla</translation>
    </message>
    <message>
        <location filename="../libs/utils_config.py" line="423"/>
        <source>Screen</source>
        <translation>Pantalla</translation>
    </message>
    <message>
        <location filename="../libs/utils_config.py" line="215"/>
        <source>Icon size</source>
        <translation>Tamaño de los iconos</translation>
    </message>
    <message>
        <location filename="../libs/utils_config.py" line="315"/>
        <source>Enter a value between {0} and {1}:</source>
        <translation>Ingrese un valor entre {0} y {1}:</translation>
    </message>
    <message>
        <location filename="../libs/utils_dialogs.py" line="106"/>
        <source>Insert text</source>
        <translation>Insertar un texto</translation>
    </message>
    <message>
        <location filename="../libs/utils_dialogs.py" line="615"/>
        <source>Tools</source>
        <translation>Utilidades</translation>
    </message>
    <message>
        <location filename="../libs/utils_config.py" line="236"/>
        <source>Visible actions</source>
        <translation>Acciones visibles</translation>
    </message>
    <message>
        <location filename="../libs/utils_config.py" line="283"/>
        <source>Screenshot delay</source>
        <translation>Retraso de captura de pantalla</translation>
    </message>
    <message>
        <location filename="../libs/utils_config.py" line="285"/>
        <source>in milliseconds</source>
        <translation>en milisegundos</translation>
    </message>
    <message>
        <location filename="../libs/utils_config.py" line="431"/>
        <source>Tools window</source>
        <translation>Herramientas</translation>
    </message>
    <message>
        <location filename="../libs/utils_config.py" line="439"/>
        <source>Kids</source>
        <translation>Niños</translation>
    </message>
    <message>
        <location filename="../libs/utils_dialogs.py" line="215"/>
        <source>Save</source>
        <translation>Guardar</translation>
    </message>
    <message>
        <location filename="../libs/utils_dialogs.py" line="207"/>
        <source>Previous file</source>
        <translation>Archivo anterior</translation>
    </message>
    <message>
        <location filename="../libs/utils_dialogs.py" line="243"/>
        <source>Print</source>
        <translation type="obsolete">Imprimir</translation>
    </message>
    <message>
        <location filename="../libs/utils_dialogs.py" line="251"/>
        <source>Export PDF</source>
        <translation type="obsolete">Exportar en PDF</translation>
    </message>
    <message>
        <location filename="../libs/utils_dialogs.py" line="250"/>
        <source>Export SVG</source>
        <translation>Exportar a imagen SVG</translation>
    </message>
    <message>
        <location filename="../libs/utils_dialogs.py" line="506"/>
        <source>Undo</source>
        <translation>Deshacer</translation>
    </message>
    <message>
        <location filename="../libs/utils_dialogs.py" line="513"/>
        <source>Redo</source>
        <translation>Rehacer</translation>
    </message>
    <message>
        <location filename="../libs/utils_dialogs.py" line="279"/>
        <source>Create a launcher</source>
        <translation>Crear un lanzador</translation>
    </message>
    <message>
        <location filename="../libs/utils_dialogs.py" line="401"/>
        <source>Lock units</source>
        <translation>Bloquear las unidades</translation>
    </message>
    <message>
        <location filename="../libs/utils_dialogs.py" line="409"/>
        <source>Save units</source>
        <translation>Salvar las unidades</translation>
    </message>
    <message>
        <location filename="../libs/utils_dialogs.py" line="416"/>
        <source>Restore backed up units</source>
        <translation>Restaurar unidades respaldadas</translation>
    </message>
    <message>
        <location filename="../libs/utils_dialogs.py" line="423"/>
        <source>Reset units</source>
        <translation>Reiniciar las unidades</translation>
    </message>
    <message>
        <location filename="../libs/utils_dialogs.py" line="361"/>
        <source>Square (not graduated)</source>
        <translation>Escuadra (no graduada)</translation>
    </message>
    <message>
        <location filename="../libs/utils_config.py" line="333"/>
        <source>Print configuration (and PDF export)</source>
        <translation>Configuración de impresión (y exportación de PDF)</translation>
    </message>
    <message>
        <location filename="../libs/utils_config.py" line="339"/>
        <source>Print mode</source>
        <translation>Modo de impresión</translation>
    </message>
    <message>
        <location filename="../libs/utils_config.py" line="341"/>
        <source>Full page</source>
        <translation>Página completa</translation>
    </message>
    <message>
        <location filename="../libs/utils_config.py" line="343"/>
        <source>True size</source>
        <translation>Tamaño real</translation>
    </message>
    <message>
        <location filename="../libs/utils_config.py" line="354"/>
        <source>Orientation</source>
        <translation>Orientación</translation>
    </message>
    <message>
        <location filename="../libs/utils_config.py" line="356"/>
        <source>Portrait</source>
        <translation>Retrato</translation>
    </message>
    <message>
        <location filename="../libs/utils_config.py" line="358"/>
        <source>Landscape</source>
        <translation>Paisaje</translation>
    </message>
    <message>
        <location filename="../libs/utils_config.py" line="82"/>
        <source>&lt;p align=left&gt;&lt;b&gt;All space: &lt;/b&gt;the application use all the free space on desktop.&lt;/p&gt;&lt;p&gt;&lt;/p&gt;&lt;p align=left&gt;&lt;b&gt;Full screen: &lt;/b&gt;choose this if you ave problems with All space mode.&lt;/p&gt;&lt;p&gt;&lt;/p&gt;&lt;p align=center&gt;&lt;b&gt;If you change this, you need to restart application.&lt;/b&gt;&lt;/p&gt;</source>
        <translation>&lt;p align=left&gt;&lt;b&gt;Todo el espacio: &lt;/b&gt;la aplicación utiliza todo el espacio libre del escritorio.&lt;/p&gt;&lt;p&gt;&lt;/p&gt;&lt;p align=left&gt;&lt;b&gt;Pantalla completa: &lt;/b&gt;elija esta opción si tiene problemas con el modo &quot;Todo el espacio&quot;.&lt;/p&gt;&lt;p&gt;&lt;/p&gt;&lt;p align=center&gt;&lt;b&gt;Si cambia esto, debe reiniciar la aplicación.&lt;/b&gt;&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../libs/utils_config.py" line="378"/>
        <source>&lt;p align=left&gt;&lt;b&gt;Full page: &lt;/b&gt;printing will be adapted to the dimensions of the page.&lt;/p&gt;&lt;p&gt;&lt;/p&gt;&lt;p align=left&gt;&lt;b&gt;True size: &lt;/b&gt;the printed document comply with the dimensions of your figures.&lt;/p&gt;&lt;p&gt;&lt;/p&gt;</source>
        <translation>&lt;p align=left&gt;&lt;b&gt;Pagina completa: &lt;/b&gt;l&apos;impression sera adaptée aux dimensions de la page.&lt;/p&gt;&lt;p&gt;&lt;/p&gt;&lt;p align=left&gt;&lt;b&gt;Taille réelle : &lt;/b&gt;le document imprimé respectera les dimensions de vos figures.&lt;/p&gt;&lt;p&gt;&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../libs/utils_dialogs.py" line="891"/>
        <source>Custom color</source>
        <translation>Color personalizado</translation>
    </message>
    <message>
        <location filename="../libs/utils_dialogs.py" line="896"/>
        <source>Custom width</source>
        <translation>Ancho personalizado</translation>
    </message>
    <message>
        <location filename="../libs/utils_config.py" line="308"/>
        <source>Attach distance</source>
        <translation>Adjuntar distancia</translation>
    </message>
    <message>
        <location filename="../libs/utils_config.py" line="310"/>
        <source>between lines or points and ruler or square</source>
        <translation>entre líneas o puntos y regla o Escuadra</translation>
    </message>
    <message>
        <location filename="../libs/utils_dialogs.py" line="499"/>
        <source>Paste</source>
        <translation>Pegar</translation>
    </message>
    <message>
        <location filename="../libs/main.py" line="667"/>
        <source>Choose the Directory where the desktop file will be created</source>
        <translation>Elija el directorio donde se creará el archivo de escritorio</translation>
    </message>
    <message>
        <location filename="../libs/utils_about.py" line="110"/>
        <source>About {0}</source>
        <translation>Acerca de {0}</translation>
    </message>
    <message>
        <location filename="../libs/utils_about.py" line="70"/>
        <source>(version {0})</source>
        <translation>(Versión {0})</translation>
    </message>
    <message>
        <location filename="../libs/utils_about.py" line="92"/>
        <source>License</source>
        <translation>Licencia</translation>
    </message>
    <message>
        <location filename="../libs/utils_about.py" line="97"/>
        <source>Close</source>
        <translation>Cerrar</translation>
    </message>
    <message>
        <location filename="../libs/main.py" line="728"/>
        <source>Restore</source>
        <translation>Restaurar</translation>
    </message>
    <message>
        <location filename="../libs/main.py" line="819"/>
        <source>Delete this item ?</source>
        <translation>¿Eliminar este objeto?</translation>
    </message>
    <message>
        <location filename="../libs/main.py" line="988"/>
        <source>Save File</source>
        <translation>Guardar el archivo</translation>
    </message>
    <message>
        <location filename="../libs/main.py" line="1252"/>
        <source>Open File</source>
        <translation>Abrir archivo</translation>
    </message>
    <message>
        <location filename="../libs/main.py" line="1300"/>
        <source>not a valid file</source>
        <translation>No es un archivo válido</translation>
    </message>
    <message>
        <location filename="../libs/main.py" line="1322"/>
        <source>Failed to open
  {0}</source>
        <translation>Falló al abrir
  {0}</translation>
    </message>
    <message>
        <location filename="../libs/utils_graphicsview.py" line="526"/>
        <source>Open Image</source>
        <translation>Abrir imagen</translation>
    </message>
    <message>
        <location filename="../libs/main.py" line="71"/>
        <source>Pylote Files (*.plt)</source>
        <translation>Archivos Pylote (*.plt)</translation>
    </message>
    <message>
        <location filename="../libs/utils_graphicsview.py" line="523"/>
        <source>Image Files</source>
        <translation>Archivos de imagen</translation>
    </message>
    <message>
        <location filename="../libs/main.py" line="1061"/>
        <source>Failed to save
  {0}</source>
        <translation>Error al guardar
  {0}</translation>
    </message>
    <message>
        <location filename="../libs/main.py" line="1543"/>
        <source>Export as SVG File</source>
        <translation>Exportar como archivo SVG</translation>
    </message>
    <message>
        <location filename="../libs/main.py" line="1545"/>
        <source>SVG Files (*.svg)</source>
        <translation>Archivos SVG (*.svg)</translation>
    </message>
    <message>
        <location filename="../libs/main.py" line="1600"/>
        <source>Export as PDF File</source>
        <translation>Exportar como archivo PDF</translation>
    </message>
    <message>
        <location filename="../libs/main.py" line="1602"/>
        <source>PDF Files (*.pdf)</source>
        <translation>Archivos PDF (*.pdf)</translation>
    </message>
    <message>
        <location filename="../libs/utils_dialogs.py" line="697"/>
        <source>Geometry instruments</source>
        <translation>Instrumentos de geometría</translation>
    </message>
    <message>
        <location filename="../libs/utils_dialogs.py" line="759"/>
        <source>Basic tools</source>
        <translation>Herramientas básicas</translation>
    </message>
    <message>
        <location filename="../libs/utils_dialogs.py" line="761"/>
        <source>Screenshots and backgrounds</source>
        <translation>Capturas de pantalla y fondos</translation>
    </message>
    <message>
        <location filename="../libs/utils_dialogs.py" line="763"/>
        <source>Drawing tools</source>
        <translation>Herramientas de dibujo</translation>
    </message>
    <message>
        <location filename="../libs/utils_graphicsview.py" line="870"/>
        <source>click to edit</source>
        <translation>Haz click para editar</translation>
    </message>
    <message>
        <location filename="../libs/utils_dialogs.py" line="765"/>
        <source>Colors</source>
        <translation>Colores</translation>
    </message>
    <message>
        <location filename="../libs/utils_graphicsview.py" line="872"/>
        <source>Width:</source>
        <translation>Anchura:</translation>
    </message>
    <message>
        <location filename="../libs/utils_dialogs.py" line="767"/>
        <source>Widths</source>
        <translation>Anchuras</translation>
    </message>
    <message>
        <location filename="../libs/utils_dialogs.py" line="170"/>
        <source>File</source>
        <translation>Archivo</translation>
    </message>
    <message>
        <location filename="../libs/utils_dialogs.py" line="492"/>
        <source>Copy</source>
        <translation>Copiar</translation>
    </message>
    <message>
        <location filename="../libs/main.py" line="1573"/>
        <source>Export as PNG File</source>
        <translation>Exportar como archivo PNG</translation>
    </message>
    <message>
        <location filename="../libs/main.py" line="1575"/>
        <source>PNG Files (*.png)</source>
        <translation>Archivos PNG (*.png)</translation>
    </message>
    <message>
        <location filename="../libs/utils_dialogs.py" line="257"/>
        <source>Export PNG</source>
        <translation>Exportar a imagen PNG</translation>
    </message>
    <message>
        <location filename="../libs/utils_dialogs.py" line="342"/>
        <source>Ruler (not graduated)</source>
        <translation>Regla (no graduada)</translation>
    </message>
    <message>
        <location filename="../libs/utils_dialogs.py" line="688"/>
        <source>Recent Files</source>
        <translation>Archivos recientes</translation>
    </message>
    <message>
        <location filename="../libs/main.py" line="1097"/>
        <source>No name</source>
        <translation>Sin nombre</translation>
    </message>
    <message>
        <location filename="../libs/main.py" line="1110"/>
        <source>File must be saved ?</source>
        <translation>¿Guardar el archivo?</translation>
    </message>
    <message>
        <location filename="../libs/utils_dialogs.py" line="175"/>
        <source>New</source>
        <translation>Nuevo</translation>
    </message>
    <message>
        <location filename="../libs/utils_dialogs.py" line="296"/>
        <source>Transparent area</source>
        <translation>Área transparente</translation>
    </message>
</context>
</TS>
