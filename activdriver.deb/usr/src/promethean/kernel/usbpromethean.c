/*
*
*  Copyright 2006 - 2010 Promethean Ltd
*  Promethean ActivBoard/ActivHub USB Driver
*/

/*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 2 of the License, or
* (at your option) any later version.
*/

#include <linux/kernel.h>
#include <linux/input.h>
#include <linux/timer.h>
#include <linux/module.h>
#include <linux/init.h>
#include <linux/usb.h>
#include <linux/poll.h>
#include <linux/kthread.h>
#include <linux/slab.h>
#include <linux/version.h>
#include <asm/unaligned.h>

#if (LINUX_VERSION_CODE > KERNEL_VERSION(2,6,18))
/* 2.6.19 has new file structure and drops regs parms */
#include <linux/usb/input.h>
#elif (LINUX_VERSION_CODE == KERNEL_VERSION(2,6,18))
/* 2.6.18 has the new file structure but uses regs parms */
#define _PRE_2_6_18_
#include <linux/usb/input.h>
#else
/* pre 2.6.18 has the old file structure and uses regs parms */
#define _PRE_2_6_18_
#include <linux/usb_input.h>
#endif

#if (LINUX_VERSION_CODE < KERNEL_VERSION(2,6,35))
#define usb_alloc_coherent usb_buffer_alloc
#define usb_free_coherent usb_buffer_free
#endif

#if EV_VERSION >= 0x010001
#define USE_MT_API 0

#if USE_MT_API 
#include <linux/input/mt.h>
#endif

#define MAX_SLOTS 12
#define MAX_TRACKING_ID 0xfff

#else
#define USE_MT_API 0
#endif

#include <asm/uaccess.h>

#include "usbpromethean.h"
#include "../inc/linux/activioctl.h"

/*
* Version Information
*/
#define DRIVER_VERSION 	"5.18.18"
#define DRIVER_AUTHOR 	"Promethean Ltd"
#define DRIVER_DESC 	"USB Activboard/Activhub Driver"
#define DRIVER_LICENSE 	"GPL"

MODULE_AUTHOR(DRIVER_AUTHOR);
MODULE_DESCRIPTION(DRIVER_DESC);
MODULE_LICENSE(DRIVER_LICENSE);

#define USB_ACTIV_MINOR_BASE 	16*11

#define MAX_PRESSURE_LEVELS 1024
#define MAX_WIDTH 	32767
#define MAX_HEIGHT 	32767

static unsigned char __DBG_LEVEL = TRACE_LEVEL_RELEASE;
static unsigned int  __DBG_FLAGS = 0xffffffff;

#define DebugPrint(l,f,p) if ((l <= __DBG_LEVEL) && (f & __DBG_FLAGS)) printk p;

#define MAX_CIRCULAR_BUFFER_SIZE 32767
#define MAX_PACKET_BUFFER_SIZE 	 128

#define MAX_MISSED_PACKETS 5
#define MAX_COORD_PACKET_SIZE 0xf

#define MAX_INT_PIPES 0x5
#define MAX_BULK_PIPES 0x5

#define CALIBRATION_MODE_OFF 	0
#define CALIBRATION_MODE_ON		1
#define CALIBRATION_MODE_TOUCH 	2
#define CALIBRATION_MODE_SELECT 3

#define MAX_CALIB_QUAD_WIDTH 9
#define MAX_CALIB_QUAD_HEIGHT 9

//! maximum number of programs subscribing to private data. 32 should be enough !
#define MAX_PRIVATE_CLIENTS 32

/*
* usb_activ_device holds all information about the connected device, including usb_endpoint data, calibration data, etc...
*/
struct usb_activ_device {

    struct input_dev *x11dev;
    char name[128];
    char phys[64];
    enum {X11_CLOSED, X11_PENDING, X11_WAITING, X11_OPEN} x11open;
    struct usb_device *usbdev;

    int pipe_in[MAX_INT_PIPES];
    size_t max_bulk_transfer_size;
    struct urb *irq[MAX_INT_PIPES];
    signed char *data_in[MAX_INT_PIPES];
    dma_addr_t data_in_dma[MAX_INT_PIPES];
    struct semaphore input_data_ready[MAX_INT_PIPES],input_data_thread_end[MAX_INT_PIPES]; /* for read notifications */
    struct task_struct *in_processing_threads[MAX_INT_PIPES];

    int maxp;

    unsigned char initialised;

    int pipe_out[MAX_BULK_PIPES], numOutPipes, lastOutPipe;
    int idProduct;
    struct urb *write_urb;

    struct semaphore	limit_sem,          /* limiting the number of writes in progress */
            list_sem,           /* add reading clients */
            xinput_sem,         /* Used to prevent concurrent access to x11open flag*/
            endpoint_initialise_sem, /* used for concurrent acces to endpoint initialise */
            data_processor_sem; /* Multiple endpoints may process data in parallel */

    struct usb_data_list* data_list_head;

    unsigned char CompletedPacket[MAX_INT_PIPES][MAX_PACKET_BUFFER_SIZE];
    unsigned char CompletedPacketIndex[MAX_INT_PIPES], CompletedPacketSize[MAX_INT_PIPES], RemainingPacketSize[MAX_INT_PIPES];

    struct _calibration
    {
        CALIBRATION_MODE mode;
        CALIB_DATA data;

        unsigned short OnePixelX,OnePixelY;
        unsigned long KeystoneMaxCalibErr;
        unsigned char KeystoneCalibErrorFlag;

        unsigned char quad_width, quad_height;
        calibration_quad_region quads[MAX_CALIB_QUAD_WIDTH * MAX_CALIB_QUAD_HEIGHT];
    } Calibration;
    LastXYZ xyz;
    unsigned short LastX[MAX_ACTIV_PENS_PER_BOARD],LastY[MAX_ACTIV_PENS_PER_BOARD];

    unsigned short LastClickedX[MAX_ACTIV_PENS_PER_BOARD],LastClickedY[MAX_ACTIV_PENS_PER_BOARD];
    unsigned short LastUnclickedX[MAX_ACTIV_PENS_PER_BOARD],LastUnclickedY[MAX_ACTIV_PENS_PER_BOARD];

    unsigned short LastButtonState[MAX_ACTIV_PENS_PER_BOARD];
    unsigned long LastClickTime[MAX_ACTIV_PENS_PER_BOARD];

    unsigned char BoardPenMode; // 2 bits per mode, up to 4 pens fits in 1 byte
    unsigned char SlatePenMode[MAX_ACTIV_SLATES]; // 2 bits per mode, up to 1 pen fits in 1 byte
    long DoubleClickDelay, DoubleClickDistance;

    struct _touch
    {
        u8 Enabled, SystemRedirectionEnabled, RadiusEnabled;
        u8 Mode;
        u8 FingerState[MAX_ACTIV_TOUCHES_PER_BOARD];
        u8 SystemFingerState[MAX_ACTIV_TOUCHES_PER_BOARD];
        struct _point
        {
            u16 X, Y, Radius;
            s16 TrackingID;
        } Last[MAX_ACTIV_TOUCHES_PER_BOARD];
        struct _point_click
        {
            u16 X, Y;
        } LastClick[MAX_ACTIV_TOUCHES_PER_BOARD];
        unsigned long LastClickTime;
        u16 RadiusUnit;
    } Touch;


    unsigned long Timeout;
    unsigned char FirmwareUpgradeMode;
    pid_t FirmwareUpgradeProcess;

    unsigned char DelayWrites;
    unsigned long LastCommandTime;

    long LastCoordCounter, MissedCoordsCount;
    unsigned char MissedCoords[MAX_MISSED_PACKETS][MAX_COORD_PACKET_SIZE];
    unsigned char HubState;
    unsigned char ReceivedOK;
    struct _FirmwarePenState
    {
        u8 DualPens[MAX_ACTIV_PENS_PER_BOARD]; // 0 = off, 1 = exclusive (only 1 pen on board, 2 = dual allowed
        u16 PressureClickThreshold[MAX_ACTIV_PENS_PER_BOARD];
        u16 PressureLevels;
        struct timer_list timer;
    } FirmwarePenState;

    struct _PrivateData
    {
        struct file* clients[MAX_PRIVATE_CLIENTS];
        unsigned char num_clients, dirty;
        struct semaphore mtx;

    } PrivateData;
};

/*
* usb_data_list: used by readers and writers. A new one is allocated on open, and deleted on close.
*/
struct usb_data_list {
    wait_queue_head_t wait; /* for read notifications */
    struct semaphore rw_sem;
    unsigned char xferMask;
    unsigned int data_head, data_tail;
    int count;
    unsigned char data[MAX_CIRCULAR_BUFFER_SIZE];
    struct usb_data_list* next;

    struct usb_activ_device *board;
};

static struct usb_driver usb_activ_driver;

static ssize_t usb_activ_write(struct usb_activ_device *board,const char *user_buffer, size_t count, const unsigned char is_user_buffer, const unsigned char wait);
static void usb_activ_reset_endpoint(struct usb_activ_device *board,int endpoint);
static void usb_activ_send_touch_packet_to_system(struct usb_activ_device* board, TOUCH_PACKET *tp);

u8 Calibrate(unsigned short XIn, unsigned short YIn,
             unsigned short *XOut, unsigned short *YOut,
             CALIB_DATA *Calibration,
             long max_calib_err,unsigned char calib_error_flag,
             unsigned char Slate, unsigned char UseKeystone);

u8 CalibrateEx(u16 XIn, u16 YIn,
               u16 *XOut, u16 *YOut,
               u8 w, u8 h,
               calibration_quad_region *quad,
               u8 slate);

/*
* usb_activ_reset_calibration_data: helper function to reset calibration to a sensible default.
*/
void usb_activ_reset_calibration(struct usb_activ_device *board)
{
    CALIB_DATA *c = &board->Calibration.data;

    board->Calibration.quad_width = board->Calibration.quad_height = 0;

    c->m_bBox[0] = 0;
    c->m_bBox[1] =0;
    c->m_bBox[2] = 12000;
    c->m_bBox[3] = 8800;

    c->m_rbBox = 16;
    c->m_mNorm[0][0] = 0x00015F52;
    c->m_mNorm[0][1] = 0x00000687;
    c->m_mNorm[0][2] = 0xFFFFFFF8;
    c->m_mNorm[0][3] = 0xDF40E75F;
    c->m_mNorm[1][0] =  0xFFFFFC65;
    c->m_mNorm[1][1] =  0xFFFDFFAF;
    c->m_mNorm[1][2] =  0x00000008;
    c->m_mNorm[1][3] =  0x235BC0BA;
    c->m_mNorm[2][0] =  0xFFFFFEE0;
    c->m_mNorm[2][1] =  0x00001607;
    c->m_mNorm[2][2] =  0xFFFFFFE2;
    c->m_mNorm[2][3] =  0xE0177216;
    c->m_mNorm[3][0] =  0x00000000;
    c->m_mNorm[3][1] =  0x00000000;
    c->m_mNorm[3][2] =  0x00000000;
    c->m_mNorm[3][3] =  0x20000000;
    c->m_rNorm = 29;
    c->m_accy = 0;

    c->m_Outrect[0] =  0;
    c->m_Outrect[1] =  0;
    c->m_Outrect[2] =  1024;
    c->m_Outrect[3] =  768;

    c->m_desktoprect[0] =  0;
    c->m_desktoprect[1] =  0;
    c->m_desktoprect[2] =  1024;
    c->m_desktoprect[3] =  768;

    c->m_wndrect[0] =  0;
    c->m_wndrect[1] =  0;
    c->m_wndrect[2] =  1024;
    c->m_wndrect[3] =  768;
    c->m_rOutrect = 19;

    c->m_x = 0;
    c->m_y = 0;
}

void usb_activ_add_private_data_client(struct usb_activ_device* board, struct file* f)
{
    if (!board)
        return;

    if (!down_interruptible(&board->PrivateData.mtx))
    {
        if (board->PrivateData.num_clients < MAX_PRIVATE_CLIENTS)
        {
            /* counting the clients is not enough, we need to check who wants the data, in case they do it several times.*/
            s8 c = 0, empty = -1;
            for ( c = 0; c < MAX_PRIVATE_CLIENTS; c++)
            {
                if (board->PrivateData.clients[c] == f)
                {
                    break;
                }
                else
                    if ((!board->PrivateData.clients[c]) && (empty < 0))
                    {
                        /* Mark the first empty */
                        empty = c;
                    }
            }

            if (c >= MAX_PRIVATE_CLIENTS) /* not found */
            {
                board->PrivateData.clients[empty] = f;
                board->PrivateData.num_clients++;

                DebugPrint(TRACE_LEVEL_INFORMATION, DRV_DBG_BOARD_DATA,(KERN_INFO "Promethean: New private data client %d %p.\n",
                                                                        board->PrivateData.num_clients,f));
            }

            /* to avoid checking for every coordinate, we check once and the mark as clean, and
            remark as dirty next time someone sets the destination. */
            board->PrivateData.dirty = 1;
        }
        up(&board->PrivateData.mtx);
    }
}

void usb_activ_remove_private_data_client(struct usb_activ_device* board, struct file* f)
{
    if (!board)
        return;

    if (!down_interruptible(&board->PrivateData.mtx))
    {
        if (board->PrivateData.num_clients < MAX_PRIVATE_CLIENTS)
        {
            /* counting the clients is not enough, we need to check who wants the data, in case they do it several times.*/
            if (board->PrivateData.num_clients)
            {
                s8 c = 0;
                for ( c = 0; c < MAX_PRIVATE_CLIENTS; c++)
                {
                    if (board->PrivateData.clients[c] == f)
                    {
                        break;
                    }
                }

                if (c < MAX_PRIVATE_CLIENTS) /* found */
                {
                    board->PrivateData.clients[c] = 0;
                    board->PrivateData.num_clients--;

                    DebugPrint(TRACE_LEVEL_INFORMATION, DRV_DBG_BOARD_DATA,(KERN_INFO "Promethean: Removed private data client %d %p.\n",
                                                                            board->PrivateData.num_clients,f));
                }

                /* to avoid checking for every coordinate, we check once and the mark as clean, and
                remark as dirty next time someone sets the destination. */
                board->PrivateData.dirty = 1;
            }
        }
        up(&board->PrivateData.mtx);
    }
}

void usb_activ_check_private_data_clients(struct usb_activ_device* board)
{
    if (!board)
        return;

    if (!down_interruptible(&board->PrivateData.mtx))
    {
        if ((board->PrivateData.num_clients == 0) && (board->PrivateData.dirty))
        {
            unsigned char ps = 0;
            /*
               check if the pens are set to private, and reset to system
               */
            if (board->Touch.Mode == DEST_APP)
                board->Touch.Mode = DEST_OS;

            for (ps = 0; ps < 4; ps++)
            {
                if ((board->BoardPenMode & (0x3 << (ps*2))) == DEST_APP)
                {
                    board->BoardPenMode &= ~(0x3 << (ps*2));
                    board->BoardPenMode |= DEST_OS << (ps*2);
                }
            }

            for (ps = 0; ps < MAX_ACTIV_SLATES; ps++)
            {
                if ((board->SlatePenMode[ps] & 0x3) == DEST_APP)
                {
                    board->SlatePenMode[ps] = DEST_OS;
                }
            }

            board->PrivateData.dirty = 0;
        }
        up(&board->PrivateData.mtx);
    }
}


/*
* Wait for a write to be complete (ie the callback is called)
*/
void waitForWriteCompletion(struct usb_activ_device* board)
{
    if (!down_interruptible(&board->limit_sem))
        up(&board->limit_sem);
}

/*
* usb_activ_xinput_open_mode: remember whether X11 has opened us or not (for coords processing).
* This way we can use activconsole without X running.
*/
void usb_activ_xinput_open_mode(struct usb_activ_device *board, unsigned char mode)
{
    if (!board)
        return;

    if (!down_interruptible(&board->xinput_sem)) {
        board->x11open = mode;
        up(&board->xinput_sem);
    }
}

/*
* usb_activ_xinput_open_mode: remember whether X11 has opened us or not (for coords processing).
* This way we can use activconsole without X running.
*/
unsigned char usb_activ_get_xinput_open_mode(struct usb_activ_device *board)
{
    unsigned char mode = X11_CLOSED;

    if (!board)
        return mode;

    if (!down_interruptible(&board->xinput_sem)) {
        mode = board->x11open;
        up(&board->xinput_sem);
    }

    return mode;
}

/*
* usb_activ_initialise_endpoints: this sets the first urbs at startup and in the case of 2.4 hub sends a :Q1 command
* to start the firmware up.
* For some reason, this doesn't work if it is called from the probe function.
* Instead we call it from either usb_activ_file_open or usb_activ_xinput_activ_open.
*/

void usb_activ_initialise_endpoints(struct usb_activ_device* board)
{
    int p = 0, retries = 200;

    if (!down_interruptible(&board->endpoint_initialise_sem))
    {
        DebugPrint(TRACE_LEVEL_VERBOSE, DRV_DBG_INIT,(KERN_INFO "Promethean: >> usb_activ_initialise_endpoints Initialised %d x11 %d.\n",
                                                      board->initialised,
                                                      board->x11open));

        if (!board->initialised) {
            for (p = 0; p < MAX_INT_PIPES ; p++) {
                if (board->irq[p]) {
                    board->irq[p]->dev = board->usbdev;

                    usb_activ_reset_endpoint(board,board->pipe_in[p]);

                    if (usb_submit_urb(board->irq[p], GFP_KERNEL))
                        break;
                }
            }

            if (board->irq[1]) // ac3, 2.4 hub
            {
                for (p = 0; p < MAX_BULK_PIPES; p++)
                {
                    if (board->pipe_out[p])
                        usb_activ_reset_endpoint(board,board->pipe_out[p]);
                }

                usb_activ_write(board,":PW1\r",5,FALSE, TRUE);

                usb_activ_write(board,":Q1\r",4,FALSE, TRUE);
                switch (board->idProduct)
                {
                case 5: //Slate 60 needs to :Q1
                    usb_activ_write(board,":Q1\r",4,FALSE, TRUE);
                    break;
                }

                // wait for the reply
                while ((!board->initialised) && retries)
                {
                    schedule_timeout_interruptible(msecs_to_jiffies(50));
                    retries--;

                    if (!(retries % 100))
                        usb_activ_write(board,":Q1\r",4,FALSE, TRUE);
                }

                DebugPrint(TRACE_LEVEL_RELEASE, DRV_DBG_INIT,(KERN_INFO "Promethean: initialised ? %d.\n", board->initialised));

                switch (board->idProduct)
                {
                case 3: //2.4
                    usb_activ_write(board,":AC\r",4,FALSE, TRUE);
                    break;
                case 4: //AC3
                case 5: //Slate 60
                case 6: //Project X
                    usb_activ_write(board,":AC1\r",5,FALSE, TRUE);
                    break;
                default:
                    usb_activ_write(board,":ST\r",4,FALSE, TRUE);
                    break;
                }
            }
            else
            {
                board->initialised = TRUE;
            }
        }
        up(&board->endpoint_initialise_sem);
    }

    DebugPrint(TRACE_LEVEL_VERBOSE, DRV_DBG_INIT,(KERN_INFO "Promethean: << usb_activ_initialise_endpoints Init %d x11 %d.\n",
                                                  board->initialised,
                                                  board->x11open              ));
}

/*
* 	/dev/ACTIVBoard device operations
*
*/

static unsigned int usb_activ_poll(struct file *file, poll_table *wait)
{
    unsigned int mask = 0;

    struct usb_data_list* list;
    struct usb_activ_device *board;

    list = (struct usb_data_list *)file->private_data;
    if (list == NULL)
        return POLLERR;

    board = list->board;

    if ((list->count < 0) || (!board))
        return POLLERR;

    /*
     * The buffer is circular; it is considered full
     * if "wp" is right behind "rp" and empty if the
     * two are equal.
     */


    if (!down_interruptible(&list->rw_sem))
    {
        if (!file->private_data) // may have been reset by the release function while we were waiting.
            mask = POLLERR;

        if (list->count < 0)
            mask = POLLERR;

        if (mask != POLLERR)
            if (list->count != 0)
                mask |= POLLIN | POLLRDNORM;    /* readable */

        up(&list->rw_sem);
    }

    // always ready to write
    if (mask != POLLERR)
        mask |= POLLOUT | POLLWRNORM;   /* writable */

    //DebugPrint(TRACE_LEVEL_VERBOSE,DRV_DBG_BOARD_DATA,(KERN_INFO "Promethean: Wait on poll...\n"));

    poll_wait(file, &list->wait,  wait);

    //DebugPrint(TRACE_LEVEL_VERBOSE,DRV_DBG_BOARD_DATA,(KERN_INFO "Promethean: poll = %x on %p.\n",mask,&list->wait));
    return mask;
}

/*
* 	usb_activ_file_open: allocate a usb_data_list and associate it with the file object.
*/
static int usb_activ_file_open(struct inode *inode, struct file *file)
{
    struct usb_activ_device *board;
    struct usb_data_list* list;

    struct usb_interface *interface;
    int subminor;
    int retval = 0;

    subminor = iminor(inode);
    interface = usb_find_interface(&usb_activ_driver, subminor);

    if (!interface) {
        retval = -ENODEV;
        goto exit;
    }

    board = usb_get_intfdata(interface);
    if (!board) {
        retval = -ENODEV;
        goto exit;
    }

    if (!(list = kmalloc(sizeof(struct usb_data_list), GFP_KERNEL)))
        return -ENOMEM;

    DebugPrint(TRACE_LEVEL_INFORMATION,DRV_DBG_USER_DATA,(KERN_INFO "Promethean: Opening from PID %d.\n",current->pid));

    memset(list, 0, sizeof(struct usb_data_list));
    list->board = board;
    list->xferMask = ACTIV_XFER_INFO;

    if (!down_interruptible(&board->list_sem)) {
        list->next = board->data_list_head;
        board->data_list_head = list;

        up(&board->list_sem);
    }

    init_waitqueue_head(&list->wait);
    sema_init(&list->rw_sem,1);
    file->private_data = list;

exit:
    return retval;
}

/*
* 	usb_activ_file_release: release the usb_data_list associated with this file.
*/
static int usb_activ_file_release(struct inode *inode, struct file *file)
{
    struct usb_data_list* list;
    struct usb_activ_device *board;
    struct usb_data_list *cur;


    list = (struct usb_data_list *)file->private_data;

    if (list == NULL)
        return -ENODEV;

    /* update the list */
    board = list->board;


    if (!board)
        return -ENODEV;

    usb_activ_remove_private_data_client(board, file);

    DebugPrint(TRACE_LEVEL_INFORMATION,DRV_DBG_USER_DATA,(KERN_INFO "Promethean: Releasing from PID %d.\n",current->pid));
    if (!down_interruptible(&board->list_sem)) {
        cur = board->data_list_head;

        while ((cur) && (cur!=list)) {
            if (cur->next == list)
            {
                cur->next = list->next;
                break;
            }
            cur= cur->next;
        }

        if (board->data_list_head == list)
            board->data_list_head = list->next;

        /* just in case it's waiting on a read */
        list->data_head = 0;
        list->data_tail = 0;
        list->count = -1;

        file->private_data = NULL;
        wake_up_interruptible(&list->wait);

        up(&board->list_sem);
    }
    kfree(list);
    return 0;
}

/*
* 	usb_activ_file_write_bulk_callback: Write urb completion routine.
*/
#ifdef _PRE_2_6_18_
static void usb_activ_file_write_bulk_callback(struct urb *urb, struct pt_regs *regs)
#else
static void usb_activ_file_write_bulk_callback(struct urb *urb)
#endif
{
    struct usb_activ_device *board;

    board = (struct usb_activ_device *)urb->context;
    if (!board)
        return;



    usb_free_coherent(urb->dev, urb->transfer_buffer_length,
                      urb->transfer_buffer, urb->transfer_dma);
    usb_free_urb(board->write_urb);
    board->write_urb = NULL;
    board->lastOutPipe = (board->lastOutPipe + 1) % board->numOutPipes;
    up(&board->limit_sem);
}

/*
* 	CheckForFirmwareUpgradeCommand: check if we are starting or ending a firmware upgrade session.
* If thast's the case, store the pid of the upgrader, and then block out all commands that aren't from this process.
*/

void CheckForFirmwareUpgradeCommand(struct usb_activ_device *board, const char *Command, size_t Len)
{
    u8 old = board->FirmwareUpgradeMode;

    if (Command && (Len > 3))
    {
        // :SF start firmware upgrade (2.4 hub)
        if ((Command[0] == ':') && (Command[1]=='S') && (Command[2]=='F') && (Command[3]=='\r'))
        {
            board->FirmwareUpgradeMode = TRUE;
            board->FirmwareUpgradeProcess = current->pid;
        }
        else
            if ((Command[0] == ':') && (Command[1]=='F') && (Command[2]=='X') && (Command[4]=='\r'))
            {
                board->FirmwareUpgradeMode = Command[3] == '1';
                board->FirmwareUpgradeProcess = current->pid;
            }
            else // :XX: dummy command to foce upgrade mode
                if ((Command[0] == ':') && (Command[1]=='X') && (Command[2]=='X') && (Command[3]=='\r'))
                {
                    board->FirmwareUpgradeMode = TRUE;
                    board->FirmwareUpgradeProcess = current->pid;
                }
                else // :XY force exit of upgrade mode
                    if ((Command[0] == ':') && (Command[1]=='X') && (Command[2]=='Y') && (Command[3]=='\r'))
                    {
                        board->FirmwareUpgradeMode = FALSE;
                        board->FirmwareUpgradeProcess = (pid_t)0;
                    }
        if ((Command[0] == ':') && (Command[1]=='C') && (Command[2]=='D') && (Command[Len-1]=='\r'))
        {
            board->FirmwareUpgradeMode = TRUE;
            board->FirmwareUpgradeProcess = current->pid;
        }
        else // :ED End firmware upgrade (2.4 hub)
            if ((Command[0] == ':') && (Command[1]=='E') && (Command[2]=='D') && (Command[3]=='\r'))
            {
                board->FirmwareUpgradeMode = FALSE;
                board->FirmwareUpgradeProcess = (pid_t)0;
            }
            else // :FU starts firmware upgrade (AC1/AC2 usb)
                if ((Command[0] == ':') && (Command[1]=='F') && (Command[2]=='U') && (Command[3]=='\r'))
                {
                    board->FirmwareUpgradeMode = TRUE;
                    board->FirmwareUpgradeProcess = current->pid;
                }
        if (board->idProduct >= 3)
        {
            if (board->FirmwareUpgradeMode != old)
                board->DelayWrites = board->FirmwareUpgradeMode ?  0 : 3;
        }
    }
}

#if (LINUX_VERSION_CODE < KERNEL_VERSION(4,15,0))
void penStateTimerCallback(unsigned long data)
{
    struct usb_activ_device *board = (struct usb_activ_device *)data;
#else
void penStateTimerCallback(struct timer_list * tl)
{
    struct usb_activ_device *board = from_timer(board, tl, FirmwarePenState.timer);
#endif
    if (board)
    {
        /* send command to hub */
        u8 command[32];
        u8 ndx = 0, val = 0, p = 0;

        command[ndx++] = ':';
        command[ndx++] = 'W';
        command[ndx++] = 'B';
        command[ndx++] = '0';
        command[ndx++] = '0';
        command[ndx++] = '2';
        command[ndx++] = '\r';
        command[ndx++] = 4; // 4 data bytes

        val = 0;
        for (p = 0; p < 2; p++) // only two on ac3 wireless
            val |= board->FirmwarePenState.DualPens[p] << (p * 2);
        val |= (u8)(board->FirmwarePenState.PressureLevels << 4);

        command[ndx++] = val;

        command[ndx++] = (u8)board->FirmwarePenState.PressureClickThreshold[0];
        command[ndx++] = (u8)board->FirmwarePenState.PressureClickThreshold[1];
        command[ndx++] = 0;

        // !!! DO NOT WAIT FOR THE END OF WRITE FROM TIMER CALLBACK !!!
        usb_activ_write(board,command,ndx,FALSE,
                        FALSE); // OTHER FUNCTIONS HOULD USE TRUE HERE
    }
}

u8 StorePenState(struct usb_activ_device *board, const char *Command, size_t Len)
{
    u16 end = Len - 1;

    if (board->idProduct != 3)
        return FALSE;
    if (Command[0] != ':')
        return FALSE;
    if (Command[end] != '\r')
        return FALSE;

    if (Command[1] == 'P')
    {
        s8 pen;
        u8 delayWBCommand = TRUE;

        pen = Command[3] - '1';
        switch (Command[2])
        {
        case 'N': // PN / pen number / state
            if ((pen >=0) && (pen < MAX_ACTIV_PENS_PER_BOARD))
                board->FirmwarePenState.DualPens[pen] = Command[4] - '0';
            break;
        case 'B': // PB / pen number / pressure click threshold
            if ((pen >=0) && (pen < MAX_ACTIV_PENS_PER_BOARD))
            {
                unsigned short c = end-1, tens = 1;
                board->FirmwarePenState.PressureClickThreshold[pen] = 0;
                while (c >= 4)
                {
                    board->FirmwarePenState.PressureClickThreshold[pen] += (Command[c]-'0') * tens;
                    c--;
                    tens *= 10;
                }
            }
            break;
        case 'S': // PS / pressure levels
        {
            unsigned short c = end-1, tens = 1;
            board->FirmwarePenState.PressureLevels = 0;
            while (c >= 3)
            {
                board->FirmwarePenState.PressureLevels += (Command[c]-'0') * tens;
                c--;
                tens *= 10;
            }
        }
            break;
        default:
            delayWBCommand = FALSE;
            break;
        }

        if (delayWBCommand)
        {
            unsigned long now;
            now = jiffies;
            mod_timer(&board->FirmwarePenState.timer, now + msecs_to_jiffies(500));
        }

        return delayWBCommand;
    }

    return FALSE;
}

/*
* 	usb_activ_file_write: send data to the board/hub.
*/
static ssize_t usb_activ_file_write(struct file *file, const char *user_buffer, size_t count, loff_t *ppos)
{
    struct usb_data_list* list;
    struct usb_activ_device *board;
    ssize_t ret = 0;

    char cmd[count + 1];
    cmd[sizeof cmd - 1] = '\0';
    if(copy_from_user(cmd, user_buffer, count))
    {
        DebugPrint(TRACE_LEVEL_VERBOSE,DRV_DBG_USER_DATA,(KERN_INFO "Promethean: usb_activ_file_write copy to kern failed\n"));
        return -EFAULT;
    }

    DebugPrint(TRACE_LEVEL_VERBOSE,DRV_DBG_USER_DATA,(KERN_INFO "Promethean: usb_activ_file_write cmd: %s, count: %zu\n",cmd,count));

    list = (struct usb_data_list *)file->private_data;
    if (list == NULL)
        return -ENODEV;

    board = list->board;

    if ((list->count < 0) || (!board))
        return -ENODEV;


    if (count <= 0)
        return 0;


    if (board)
    {
        CheckForFirmwareUpgradeCommand(board, cmd, count);
        if (board->FirmwareUpgradeMode && (current->pid != board->FirmwareUpgradeProcess))
        {
            DebugPrint(TRACE_LEVEL_CRITICAL, DRV_DBG_USER_DATA,(KERN_INFO "Promethean: ##WARNING: Firmware update in progress, another process tried to send a command which was blocked.\n"));
            return -ENODEV;
        }
    }

    if ((board) && (!board->initialised))
        usb_activ_initialise_endpoints(board);

    if (board)
    {
        if (StorePenState(board, cmd, count))
            return 0;
    }

    if (!board->FirmwareUpgradeMode)
    {
        if ((count  > 3) && (!memcmp(cmd,":VE\r",4)))
        {
            if (board->HubState != 0)
                schedule_timeout_interruptible(msecs_to_jiffies(2000));
            board->ReceivedOK = FALSE;
        }
    }

    ret = usb_activ_write(board,cmd, count,FALSE, TRUE);

    if (!board->FirmwareUpgradeMode)
    {
        if ((count  > 3) && (!memcmp(cmd,":TM\r",4)))
        {
            board->Calibration.mode = CALIBRATION_MODE_TOUCH;
        }
        else
            if ((count  > 3) && (!memcmp(cmd,":ZM",3)))
            {
                board->Calibration.mode = cmd[3] - '0';
                DebugPrint(TRACE_LEVEL_INFORMATION, DRV_DBG_USER_DATA,(KERN_INFO "Promethean: Calibration Mode %d.\n",board->Calibration.mode));
            }
            else
                if ((count  > 3) && (!memcmp(cmd,":VE\r",4)))
                {
                    // wait for OK
                    u8 retries = 100;

                    while ((!board->ReceivedOK) && (--retries))
                    {
                        schedule_timeout_interruptible(msecs_to_jiffies(50));
                    }
                }
    }

    return ret;
}


/*
* 	usb_activ_file_ioctl: various IOCTL to set internal data structures or read them back.
*/
static long usb_activ_file_ioctl (struct file *file, unsigned int cmd, unsigned long arg)
{
    int retval = -ENODEV;
    int timeout = 0;
    unsigned char debugMode = 0;
    unsigned int debugLevel = 0;
    unsigned char xferMask = 0;
    unsigned char touch_mode = 0;
    unsigned short pen_mode = 0, distance = 0;
    struct usb_data_list* list;
    struct usb_activ_device *board;
    TOUCH_PACKET tp;

    if (_IOC_TYPE(cmd) != PROMETHEAN_ACTIV_IOCTL) return -ENOTTY;
    if (_IOC_NR(cmd) > PROMETHEAN_ACTIV_IOCTL_NUM) return -ENOTTY;

    retval = 0;
    if (_IOC_DIR(cmd) & _IOC_READ)
#if (LINUX_VERSION_CODE < KERNEL_VERSION(5,0,0))
        retval = !access_ok(VERIFY_WRITE,(void __user *)arg, _IOC_SIZE(cmd));
#else
        retval = !access_ok((void __user *)arg, _IOC_SIZE(cmd));
#endif        
    if (_IOC_DIR(cmd) & _IOC_WRITE)
#if (LINUX_VERSION_CODE < KERNEL_VERSION(5,0,0))
        retval = !access_ok(VERIFY_READ,(void __user *)arg, _IOC_SIZE(cmd));
#else
        retval = !access_ok((void __user *)arg, _IOC_SIZE(cmd));
#endif        

    if (retval) return -EFAULT;

    list = (struct usb_data_list*)file->private_data;
    if (!list)  return -ENOTTY;

    board = list->board;
    if (!board) return -ENOTTY;


    switch (cmd) {
    case ACTIV_SET_CALIBRATE_MODE:
        if (copy_from_user(&board->Calibration.mode, (void*)arg,_IOC_SIZE(cmd))) {
            board->Calibration.mode = CALIBRATION_MODE_OFF;
        }
        break;
    case ACTIV_GET_LAST_XYZ:
        if (copy_to_user((void*)arg,&board->xyz, _IOC_SIZE(cmd))) {
            // cannot write to user buffer.
        }
        break;
    case ACTIV_SET_PEN_DESTINATION:
        //_IOW(PROMETHEAN_ACTIV_IOCTL,	8, unsigned short)     /* UPDATE NUM WHEN ADDING IOCTLs ! */

        if (copy_from_user(&pen_mode, (void*)arg,_IOC_SIZE(cmd))) {
            DebugPrint(TRACE_LEVEL_CRITICAL, DRV_DBG_USER_DATA,(KERN_INFO "Promethean: Set pen destination fail.\n"));
        }
        else {
            unsigned char is_slate = (pen_mode & 0x8000)?1:0;
            unsigned char pen_or_slate = 0;
            unsigned char mode = 0;

            pen_mode &= 0x7fff;
            pen_or_slate = (((pen_mode >> 8) & 0xff) -1);
            if (is_slate)
                pen_or_slate = pen_or_slate % MAX_ACTIV_SLATES;
            else
                pen_or_slate = pen_or_slate % MAX_ACTIV_PENS_PER_BOARD;
            mode = pen_mode & 0x3;

            DebugPrint(TRACE_LEVEL_RELEASE, DRV_DBG_USER_DATA,(KERN_INFO "Promethean: Set pen destination: Pen %d Slate? %d Mode %d.\n",pen_or_slate,is_slate,mode));

            if (is_slate)
            {
                board->SlatePenMode[pen_or_slate] &= ~(0x3);
                board->SlatePenMode[pen_or_slate] |= mode;
            }
            else
            {
                // TODO: for now use the first board, we haven't got a way to address multiple AC3 boards in this ioctl.
                board->BoardPenMode &= ~(0x3 << (pen_or_slate*2));
                board->BoardPenMode |= (mode << (pen_or_slate*2));
            }

            switch (mode)
            {
            case DEST_APP:
                usb_activ_add_private_data_client(board, file);
                break;
            }
        }
        break;
    case ACTIV_GET_PEN_DESTINATION:
        if (!copy_from_user(&pen_mode, (void*)arg,_IOC_SIZE(cmd))) {

            unsigned char is_slate = (pen_mode & 0x8000)?1:0;
            unsigned char pen_or_slate = 0;

            pen_mode &= 0x7fff;
            pen_or_slate = (((pen_mode >> 8) & 0xff) -1);
            if (is_slate)
                pen_or_slate = pen_or_slate % MAX_ACTIV_SLATES;
            else
                pen_or_slate = pen_or_slate % MAX_ACTIV_PENS_PER_BOARD;

            if (is_slate)
                pen_mode = board->SlatePenMode[pen_or_slate];
            else
            {
                pen_mode =  (board->BoardPenMode >> (pen_or_slate*2)) & 0x3;
            }

            if (copy_to_user((void*)arg,&pen_mode, _IOC_SIZE(cmd)))
            {
                DebugPrint(TRACE_LEVEL_CRITICAL, DRV_DBG_USER_DATA,(KERN_INFO "Promethean: ERROR returning PEN INFO\n"));
            }
        }
        else
        {
            DebugPrint(TRACE_LEVEL_CRITICAL, DRV_DBG_USER_DATA,(KERN_INFO "Promethean: ERROR GETTING PEN INFO\n"));
        }
        break;

    case ACTIV_GET_TOUCH_DESTINATION:
        if (copy_to_user((void*)arg,&board->Touch.Mode, _IOC_SIZE(cmd)))
        {
            DebugPrint(TRACE_LEVEL_CRITICAL, DRV_DBG_USER_DATA,(KERN_INFO "Promethean: ERROR returning touch mode\n"));
        }
        break;
    case ACTIV_SET_TOUCH_DESTINATION:
        if (copy_from_user(&touch_mode, (void*)arg,_IOC_SIZE(cmd))) {
            /* keep transfer mask as is in case of error */
        } else {
            board->Touch.Mode = touch_mode;
            DebugPrint(TRACE_LEVEL_CRITICAL, DRV_DBG_USER_DATA,(KERN_INFO "Promethean: Setting touch destination to %d\n", touch_mode));

            switch (touch_mode)
            {
            case DEST_APP:
                usb_activ_add_private_data_client(board, file);
                break;
            }
        }
        break;

    case ACTIV_GET_TOUCH_ENABLED:
        if (copy_to_user((void*)arg,&board->Touch.Enabled, _IOC_SIZE(cmd)))
        {
            DebugPrint(TRACE_LEVEL_CRITICAL, DRV_DBG_USER_DATA,(KERN_INFO "Promethean: ERROR returning touch enable\n"));
        }
        break;
    case ACTIV_SET_TOUCH_ENABLED:
        if (copy_from_user(&touch_mode, (void*)arg,_IOC_SIZE(cmd))) {
            /* keep transfer mask as is in case of error */
        } else {
            board->Touch.Enabled= touch_mode;
            DebugPrint(TRACE_LEVEL_CRITICAL, DRV_DBG_USER_DATA,(KERN_INFO "Promethean: Setting touch enabled to %d\n", touch_mode));
        }
        break;

    case ACTIV_GET_TOUCH_SYSTEM_REDIRECTION_ENABLED:
        if (copy_to_user((void*)arg,&board->Touch.SystemRedirectionEnabled, _IOC_SIZE(cmd)))
        {
            DebugPrint(TRACE_LEVEL_CRITICAL, DRV_DBG_USER_DATA,(KERN_INFO "Promethean: ERROR returning system redirection touch enable\n"));
        }
        break;
    case ACTIV_SET_TOUCH_SYSTEM_REDIRECTION_ENABLED:
        if (copy_from_user(&touch_mode, (void*)arg,_IOC_SIZE(cmd))) {
            /* keep transfer mask as is in case of error */
        } else {
            board->Touch.SystemRedirectionEnabled = touch_mode;
            DebugPrint(TRACE_LEVEL_CRITICAL, DRV_DBG_USER_DATA,(KERN_INFO "Promethean: Setting touch to system enabled to %d\n", touch_mode));
        }
        break;

    case ACTIV_SET_TIMEOUT:
        if (copy_from_user(&timeout, (void*)arg,_IOC_SIZE(cmd)))
        {
            /* error: keep timeout as it is. */
        } else {
            board->Timeout = (timeout * HZ) / 1000;
        }
        break;
    case ACTIV_SET_DRIVER_DEBUG_MODE:
        if (copy_from_user(&debugMode, (void*)arg,_IOC_SIZE(cmd)))
        {
            /* error: keep timeout as it is. */
        } else {
            __DBG_LEVEL = debugMode;
            DebugPrint(TRACE_LEVEL_CRITICAL,DRV_DBG_USER_DATA,(KERN_INFO "Promethean: Set driver debug level to %x\n", debugMode));
        }
        break;
    case ACTIV_SET_DRIVER_DEBUG_LEVEL:
        if (copy_from_user(&debugLevel, (void*)arg,_IOC_SIZE(cmd)))
        {
            /* error: keep timeout as it is. */
        } else {
            __DBG_FLAGS = debugLevel;
            DebugPrint(TRACE_LEVEL_CRITICAL,DRV_DBG_USER_DATA,(KERN_INFO "Promethean: Set driver debug flags to %x\n", debugLevel));
        }
        break;
    case ACTIV_SET_XFER_MASK:
        if (copy_from_user(&xferMask, (void*)arg,_IOC_SIZE(cmd))) {
            /* keep transfer mask as is in case of error */
        } else {
            list->xferMask = xferMask & (ACTIV_XFER_COORDINATES|ACTIV_XFER_PRESSURE|ACTIV_XFER_INFO);
        }
        break;
    case ACTIV_FLUSH_QUEUE:
        if (!down_interruptible(&list->rw_sem)) {
            list->count = 0;
            list->data_head = list->data_tail = 0;

            up(&list->rw_sem);
        }

        break;
    case ACTIV_CANCEL_READ:
        DebugPrint(TRACE_LEVEL_RELEASE,DRV_DBG_USER_DATA,(KERN_INFO "Promethean: Cancel Read Operation %p.\n", &list->wait));
        if (!down_interruptible(&list->rw_sem)) {
            list->count = -1;
            list->data_head = list->data_tail = 0;
            up(&list->rw_sem);

            wake_up_interruptible(&list->wait);
        }
        break;
    case ACTIV_SET_CALIBRATION_DATA_EX:
    {
        quad_data_t qdata;
        DebugPrint(TRACE_LEVEL_RELEASE,DRV_DBG_USER_DATA,(KERN_INFO "Promethean: Calibrating v2 Device PID %d.\n",current->pid));
        if (copy_from_user(&qdata, (void*)arg,_IOC_SIZE(cmd))) {
            usb_activ_reset_calibration(board);
        } else {
            DebugPrint(TRACE_LEVEL_RELEASE,DRV_DBG_USER_DATA,(KERN_INFO "Promethean: %d/%d/%d.\n", qdata.ndx, qdata.width, qdata.height));
            if (qdata.ndx == 0xff)
            {
                // saving the calibration is done in the calibration program.

            }
            else
                if (qdata.ndx < (qdata.width*qdata.height))
                {
                    memcpy(&board->Calibration.quads[qdata.ndx], &qdata.quad, sizeof(calibration_quad_region));

                    if (!qdata.ndx)
                    {
                        board->Calibration.quad_width = qdata.width;
                        board->Calibration.quad_height = qdata.height;

                        board->Calibration.data.m_desktoprect[0] = 0;
                        board->Calibration.data.m_desktoprect[1] = 0;
                        board->Calibration.data.m_desktoprect[2] = qdata.quad.desktop_size.x;
                        board->Calibration.data.m_desktoprect[3] = qdata.quad.desktop_size.y;

                        board->Calibration.data.m_wndrect[0] = qdata.quad.screen_rect.left;
                        board->Calibration.data.m_wndrect[1] = qdata.quad.screen_rect.top;
                        board->Calibration.data.m_wndrect[2] = qdata.quad.screen_rect.right + 1;
                        board->Calibration.data.m_wndrect[3] = qdata.quad.screen_rect.bottom + 1;

                        board->Calibration.data.m_Outrect[0] = 0;
                        board->Calibration.data.m_Outrect[1] = 0;
                        board->Calibration.data.m_Outrect[2] = qdata.quad.screen_rect.right - qdata.quad.screen_rect.left  + 1;
                        board->Calibration.data.m_Outrect[3] = qdata.quad.screen_rect.bottom - qdata.quad.screen_rect.top  + 1;
                    }
                }
        }
    }
        break;
    case ACTIV_SET_CALIBRATION_DATA:
        DebugPrint(TRACE_LEVEL_RELEASE,DRV_DBG_USER_DATA,(KERN_INFO "Promethean: Calibrating Device PID %d.\n",current->pid));

        if (copy_from_user(&board->Calibration.data, (void*)arg,_IOC_SIZE(cmd))) {
            usb_activ_reset_calibration(board);
        } else {
            /* recompute the keystone */
            unsigned short KX,KY;
            const unsigned short midway = MAX_MOUSE_RANGE / 2;
            board->Calibration.quad_height = board->Calibration.quad_width = 0;

            if (Calibrate((unsigned short)board->Calibration.data.m_x,
                          (unsigned short)board->Calibration.data.m_y,
                          &KX,&KY,
                          &board->Calibration.data,
                          0,FALSE,
                          FALSE,
                          FALSE)) {

                if (KY >= midway) {
                    board->Calibration.KeystoneCalibErrorFlag = FALSE;
                    board->Calibration.KeystoneMaxCalibErr   = KY - midway;
                } else {
                    board->Calibration.KeystoneCalibErrorFlag = TRUE;
                    board->Calibration.KeystoneMaxCalibErr    = midway - KY;
                }
            }

            if (board->Calibration.data.m_wndrect[2]-board->Calibration.data.m_wndrect[0])
                board->Calibration.OnePixelX = (unsigned short)(MAX_MOUSE_RANGE / (board->Calibration.data.m_desktoprect[2]-board->Calibration.data.m_desktoprect[0]));

            if (board->Calibration.data.m_desktoprect[3]-board->Calibration.data.m_desktoprect[1])
                board->Calibration.OnePixelY = (unsigned short)(MAX_MOUSE_RANGE / (board->Calibration.data.m_desktoprect[3]-board->Calibration.data.m_desktoprect[1]));

            board->Touch.RadiusUnit = 300;

            /* compute the raddius unit. In everyday use, the calib will be near the edge, so we start in the middle of
               the board. In a test environment, this may go completely wrong! */
            for (KX = 7000; KX < (14000-138); KX+=board->Calibration.OnePixelX)
            {
                unsigned short rx,ry,rrx,rry;
                for (KY = 4400; KY > 138 ; KY-=board->Calibration.OnePixelY)
                {
                    if (Calibrate(KX,
                                  KY,
                                  &rx,&ry,
                                  &board->Calibration.data,
                                  0,FALSE,
                                  FALSE,
                                  FALSE))
                    {
                        /* 1 touch cell is 137.5 raw points */
                        if (Calibrate(KX+137,
                                      KY+137,
                                      &rrx,&rry,
                                      &board->Calibration.data,
                                      0,FALSE,
                                      FALSE,
                                      FALSE))
                        {

                            if ((rrx > rx) && ((rrx - rx) < 500))
                            {
                                DebugPrint(TRACE_LEVEL_RELEASE,DRV_DBG_INIT,(KERN_INFO "Promethean: Radius is %d at %u,%u.\n",rrx-rx,KX,KY));
                                board->Touch.RadiusUnit = rrx-rx;

#if USE_MT_API
                                input_set_abs_params(board->x11dev, ABS_MT_TOUCH_MAJOR,  0, (0x7 * board->Touch.RadiusUnit), 0, 0);
#endif

                                KX = 0;
                                KY = 0;
                                break;
                            }
                        }
                    }

                }
                if ((!KX) && (!KY))
                    break;
            }
            DebugPrint(TRACE_LEVEL_RELEASE,DRV_DBG_INIT,(KERN_INFO "Promethean: One pixel is %d by %d.\n",board->Calibration.OnePixelX,board->Calibration.OnePixelY));
        }
        break;
    case ACTIV_SET_DOUBLE_CLICK_DISTANCE:
    {
        if (copy_from_user(&distance, (void*)arg,_IOC_SIZE(cmd)))
        {
            /* error: keep timeout as it is. */
        } else {
            DebugPrint(TRACE_LEVEL_RELEASE,DRV_DBG_USER_DATA,(KERN_INFO "Promethean: Setting double click distance to %d.\n",distance));
            board->DoubleClickDistance = distance;
        }
    }
        break;
    case ACTIV_GET_DRIVER_VERSION:
        if (copy_to_user((void*)arg,
                         (void*)DRIVER_VERSION,
                         (int)min((int)strlen(DRIVER_VERSION)+1, (int)_IOC_SIZE(cmd)))) {
            // cannot write to user buffer.
        }
        break;
    case ACTIV_SEND_TOUCH_TO_SYSTEM:

        if (copy_from_user(&tp, (void*)arg,_IOC_SIZE(cmd))) {
            DebugPrint(TRACE_LEVEL_CRITICAL, DRV_DBG_USER_DATA,(KERN_INFO "Promethean: Send touch to system  failed.\n"));
        }
        else {
            if (board->Touch.SystemRedirectionEnabled)
            {
                DebugPrint(TRACE_LEVEL_VERBOSE,DRV_DBG_USER_DATA,(KERN_INFO "Promethean: Sending touch packet to system.\n"));
                usb_activ_send_touch_packet_to_system(board, &tp);
            }
        }
        break;
    default:
        DebugPrint(TRACE_LEVEL_CRITICAL,DRV_DBG_USER_DATA,(KERN_INFO "Promethean: Received invalid IOCTL.\n"));
        break;

    }

    return retval;
}

/*
* 	usb_activ_file_read: read data from the usb_data_list associated with this file.
*      The  data is a logical board packet, which may be less than what is actually in the circular queue.
*/

static ssize_t usb_activ_file_read(struct file *file, char *buffer, size_t count, loff_t *ppos)
{
    int p;
    unsigned long n;
    struct usb_data_list* list;
    struct usb_activ_device *board;
    char mp[count];

    list = (struct usb_data_list *)file->private_data;
    if (list == NULL)
        return -ENODEV;

    if (list->count < 0)
        return -ENODEV;

    board = list->board;

    if (down_interruptible(&list->rw_sem))
        return -ERESTARTSYS;

    while (list->count == 0)  {
        up(&list->rw_sem);

        if (file->f_flags & O_NONBLOCK)
            return -EAGAIN;

        if (board->Timeout) {
            if (wait_event_interruptible_timeout(list->wait, (list->count != 0),board->Timeout) < 0)
                return -ERESTARTSYS;

            if (list->count == 0)
                return -ETIMEDOUT;
        }
        else {
            if (wait_event_interruptible(list->wait, (list->count != 0)))
                return -ERESTARTSYS;
        }


        if (!file->private_data) // may have been reset by the release function while we were waiting.
            return -ENODEV;

        if (list->count < 0)
            return -ENODEV;

        if (down_interruptible(&list->rw_sem))
            return -ERESTARTSYS;
    }

    /* list->data[list->data_head] is the first byte of the first packet.
* This is the length byte.
* In case of unformatted packets or split packets, this will go wrong !
* Firmware guys ensure me there won't be any split packets.
*/
    count = min(count, (size_t)list->data[list->data_head]);

    if (count > list->count) {
        DebugPrint(TRACE_LEVEL_CRITICAL,DRV_DBG_BOARD_DATA,(KERN_INFO "Promethean::Error: USB Data Length is not right: %ld requested, %d in buffer.\n",(long)count,list->count));
        count = 0;
        list->count = -1;
        list->data_head = list->data_tail = 0;

    }

    /* split the data in logical packets : even if we have three packets in the
* buffer, only send one back to the read.
*/
    for (p=0;p<count;p++) {
        mp[p] = list->data[list->data_head];
        list->data_head = (list->data_head + 1) % MAX_CIRCULAR_BUFFER_SIZE;
        list->count--;
    }

    n = copy_to_user(buffer, mp, count);

    DebugPrint(TRACE_LEVEL_VERBOSE,DRV_DBG_USER_DATA,(KERN_INFO "Promethean: usb_activ_file_read n:%lu\n",n));

    up(&list->rw_sem);

    return n == 0 ? count : -EFAULT;
}

/* file operations table for direct access by apps */
static struct file_operations usb_activ_fops = {
    .owner =	THIS_MODULE,
    .read =		usb_activ_file_read,
    .write =	usb_activ_file_write,
    .open =		usb_activ_file_open,
    .release =	usb_activ_file_release,
    .poll = usb_activ_poll,
    // better than ioctl, as this deals with thunking from 32 to 64-bit.
    .unlocked_ioctl = usb_activ_file_ioctl,
    .compat_ioctl = usb_activ_file_ioctl,
};

static struct usb_class_driver usb_activ_file_class = {
    .name =		"ACTIVBoard%d",
    .fops =		&usb_activ_fops,
    .minor_base =	USB_ACTIV_MINOR_BASE,
};


/**************************************************************************************************/

/*
* usb_calibrate: calibrate xin / yin according to calibration matrix.
*/
static int usb_activ_calibrate(struct usb_activ_device *board,
                               u16 xin, u16 yin,
                               u16 *xout, u16 *yout,
                               const u8 slate)
{

    unsigned char process = 0;

    if (board->Calibration.mode > CALIBRATION_MODE_OFF) {
        *xout = xin;
        *yout = yin;
        process = 1;
    } else {
        if (board->Calibration.quad_width)
            process = CalibrateEx(xin,yin,xout,yout,
                                  board->Calibration.quad_width, board->Calibration.quad_height, board->Calibration.quads,
                                  slate);
        else
            process = Calibrate(xin,yin,xout,yout,
                                &board->Calibration.data,
                                board->Calibration.KeystoneMaxCalibErr,
                                board->Calibration.KeystoneCalibErrorFlag,
                                slate,TRUE);
    }
    return process?1:0;
}

/*
* usb_activ_check_distance: check that distance between current and last coordinate is not sub pixel (worth sending).
*/
unsigned char usb_activ_check_distance(struct usb_activ_device *board, unsigned short X, unsigned short Y, unsigned char pen_or_slate_id)
{
    unsigned short distanceX,distanceY;
    unsigned char process= TRUE;

    distanceX = (X > board->LastX[pen_or_slate_id])?(X - board->LastX[pen_or_slate_id]):(board->LastX[pen_or_slate_id]-X);
    distanceY = (Y > board->LastY[pen_or_slate_id])?(Y - board->LastY[pen_or_slate_id]):(board->LastY[pen_or_slate_id]-Y);

    if ((distanceX < (board->Calibration.OnePixelX/2)) && (distanceY < (board->Calibration.OnePixelY/2))) {
        process = FALSE;
    }

    return process;
}

/*
* usb_activ_check_touch_distance: check that distance between current and last coordinate is not sub pixel (worth sending).
*/
unsigned char usb_activ_check_touch_distance(struct usb_activ_device *board, unsigned short X, unsigned short Y, unsigned char touch)
{
    unsigned short distanceX,distanceY;
    unsigned char process= TRUE;

    distanceX = (X > board->Touch.Last[touch].X)?(X - board->Touch.Last[touch].X):(board->Touch.Last[touch].X-X);
    distanceY = (Y > board->Touch.Last[touch].Y)?(Y - board->Touch.Last[touch].Y):(board->Touch.Last[touch].Y-Y);

    if ((distanceX < (board->Calibration.OnePixelX/2)) && (distanceY < (board->Calibration.OnePixelY/2)))
    {
        process = FALSE;
    }

    return process;
}

/*
* usb_activ_stop_files: Stop all readers on a blocking read. Called when device is disconnected
*/
static void usb_activ_stop_files(struct usb_activ_device *board)
{
    struct usb_data_list *cur = board->data_list_head;

    if (!down_interruptible(&board->list_sem)) {

        while (cur) {
            cur->data_tail = cur->data_head = 0;
            cur->count = -1;
            cur->board = NULL;

            DebugPrint(TRACE_LEVEL_CRITICAL,DRV_DBG_BOARD_DATA,(KERN_INFO "Promethean: Stopping file queue.\n"));
            wake_up_interruptible(&cur->wait);
            cur = cur->next;
        }

        up(&board->list_sem);
    }
}

/*
* usb_activ_append_file_data: append data read from the urb to the queues of waiting files.
*  Which data gets queued depends on transfer mask.
* data and length = 0 means the device is disconnected, all readers are being stopped.
*/
static void usb_activ_append_file_data(struct usb_activ_device *board, unsigned char* data, unsigned int length)
{
    struct usb_data_list *cur = board->data_list_head;
    unsigned int p = 0, head = 0, tail = 0;

    if ((!data) || (!length) || (length & 0x8000) || (!board))
        return;

    if (!down_interruptible(&board->list_sem)) {

        while (cur) {
            if (!down_interruptible(&cur->rw_sem)) {
                unsigned char send = TRUE;

                /* first check if this client wants to know about the packet we're queuing up */
                switch (data[1]) {
                case CB_COORD_PEN1:
                case CB_RF_PIC_SLATE_COORD:
                    send = (cur->xferMask & ACTIV_XFER_COORDINATES) == ACTIV_XFER_COORDINATES;
                    break;
                case CB_PRESSURE_AC3:
                    send = (cur->xferMask & ACTIV_XFER_PRESSURE) == ACTIV_XFER_PRESSURE;
                    break;
                case CB_FIRMWARE_PACKET:
                    send = (cur->xferMask & ACTIV_XFER_INFO) == ACTIV_XFER_INFO;
                    break;
                default:
                    send = (cur->xferMask & ACTIV_XFER_INFO) == ACTIV_XFER_INFO;
                    break;
                }

                /* check if it fits first */
                head = cur->data_head;
                tail = cur->data_tail;
                for (p=0;send && data && p<length;p++) {
                    tail = (tail + 1) % MAX_CIRCULAR_BUFFER_SIZE;

                    if (tail == head) {
                        /* oops: we have wrapped around
* It means the app who requested private data is probably not responding.
*/
                        DebugPrint(TRACE_LEVEL_CRITICAL,DRV_DBG_BOARD_DATA,(KERN_INFO "Promethean::Error: Buffer wrap around.\n"));
                        DebugPrint(TRACE_LEVEL_CRITICAL,DRV_DBG_BOARD_DATA,(KERN_INFO "Promethean::Error: ID %p Size %d / %d: packet not sent.\n",cur,cur->count,MAX_CIRCULAR_BUFFER_SIZE));
                        send = FALSE;
                    }
                }

                for (p=0;send && data && p<length;p++) {
                    cur->data[cur->data_tail] = data[p];
                    cur->data_tail = (cur->data_tail + 1) % MAX_CIRCULAR_BUFFER_SIZE;
                    cur->count++;
                }

                up(&cur->rw_sem);

                if (send)
                    wake_up_interruptible(&cur->wait);
            }
            cur = cur->next;
        }

        up(&board->list_sem);
    }
}

/*
* SquareRoot: non floating point square root.
*/
unsigned long SquareRoot(unsigned long a)
{
    unsigned long rem = 0;
    unsigned long root = 0;
    unsigned long divisor = 0;
    int i = 0;

    for ( i=0; i<16; i++) {
        root <<= 1;
        rem = ((rem << 2) + (a >> 30));
        a <<= 2;
        divisor = (root<<1) + 1;
        if (divisor <= rem) {
            rem -= divisor;
            root++;
        }
    }

    return root;
}

static void usb_activ_request_next_calib_point(struct usb_activ_device* board)
{
    unsigned char data[10];

    data[0] = 6;
    data[1] = CB_GENERAL;
    data[2] = 'N';
    data[3] = 'E';
    data[4] = 'X';
    data[5] = 'T';

    usb_activ_append_file_data(board, data, data[0]);
}

static void usb_activ_request_calib_quit(struct usb_activ_device* board)
{
    unsigned char data[10];

    data[0] = 6;
    data[1] = CB_GENERAL;
    data[2] = 'Q';
    data[3] = 'U';
    data[4] = 'I';
    data[5] = 'T';

    usb_activ_append_file_data(board, data, data[0]);
}

static void usb_activ_request_screen_selection(struct usb_activ_device* board)
{
    unsigned char data[10];

    data[0] = 6;
    data[1] = CB_GENERAL;
    data[2] = 'S';
    data[3] = 'E';
    data[4] = 'L';
    data[5] = 'S';

    usb_activ_append_file_data(board, data, data[0]);
}

static void usb_activ_process_touch(struct usb_activ_device* board, unsigned char *data, unsigned int length)
{
    u8 process = TRUE;
    u8 systemTouch = (board->Touch.Mode == DEST_OS) || (board->Touch.Mode == DEST_OS_APP);
    u8 privateTouch = (board->Touch.Mode == DEST_OS_APP) || (board->Touch.Mode == DEST_APP);
    u16 x = 0, y = 0, radius = 0;
    u8 privateData[0x80], privateDataSize = 0;
    u8 t = 0, touches = 12, offset;
    const u8 CoordOffset = 3;
    struct input_dev *dev = board->x11dev;
    u8 readRadiusData = FALSE, hardwareCoordinate = TRUE, penInProx = FALSE;
    u8 syncX = FALSE, moveX = FALSE, fingersDown = 0, fingersDownStart = 0;

    usb_activ_check_private_data_clients(board);

    if (!dev)
        return;

    if (board->Touch.Mode == DEST_DISABLED)
        return;

    if (board->Touch.Enabled == FALSE)
        return;


    switch (board->Calibration.mode == 1)
    {
    case CALIBRATION_MODE_ON:
    case CALIBRATION_MODE_SELECT:
        return;
    }

    readRadiusData = length == 0x3a;

    switch (data[1])
    {
    case CB_AC4_SYSTEM_COORD_DATA:
        privateTouch = FALSE;
        systemTouch = TRUE;
        readRadiusData = FALSE;
        hardwareCoordinate = FALSE;
        break;
    }

    if (board->Calibration.mode == CALIBRATION_MODE_TOUCH)
    {
        privateTouch = FALSE;
        systemTouch = FALSE;
        readRadiusData = FALSE;
    }

    if (privateTouch)
    {
        privateData[privateDataSize++] = 0;
        privateData[privateDataSize++] = CB_AC4_COORD_DATA;
    }

    if (systemTouch)
    {
        // if a pen is in prox, simulate touch up
        int p = 0;

        for (p = 0; p < MAX_ACTIV_PENS_PER_BOARD; p++)
        {
            if (board->LastButtonState[p] & 4)
            {
                penInProx = TRUE;
                break;
            }
        }
        for (t = 0; t < touches; t++)
        {
            if (board->Touch.SystemFingerState[t] & 0x1)
                fingersDownStart++;
        }
    }


    for (t = 0; t < touches; t++)
    {
        if (board->Calibration.mode == CALIBRATION_MODE_TOUCH)// only send first touch to the OS
            systemTouch = (t == 0);

        offset = CoordOffset + t*4;
        x = le16_to_cpu(*(__le16 *) &data[offset]);
        y = le16_to_cpu(*(__le16 *) &data[offset + 2]);

        if (penInProx)
            x = y = 0xffff;

        if (readRadiusData)
        {
            radius = data[ touches * 4 + CoordOffset + t/2]; // this is in nibbles...
            if (t % 2)
                radius = (radius >> 4) & 0xf;
            else
                radius = radius & 0xf;
        }
        /* Turn radius to finger off when present if radius disabled */
        if ((radius) && (!board->Touch.RadiusEnabled))
        {
            radius = 0;
            x = y = 0xffff;
        }

        if ((x != 0xffff) && (y != 0xffff))
        {
            if (hardwareCoordinate)
            {
                DebugPrint(TRACE_LEVEL_VERBOSE,DRV_DBG_BOARD_DATA,(KERN_INFO "Promethean::Raw Touch %d at %d,%d.\n",t,x,y));

                if (board->Calibration.mode == CALIBRATION_MODE_OFF)
                {
                    process = usb_activ_calibrate(board, x, y, &x, &y, FALSE);

                    DebugPrint(TRACE_LEVEL_VERBOSE,DRV_DBG_BOARD_DATA,(KERN_INFO "Promethean::Calibrated Touch %d at %d,%d.\n",t,x,y));

                    if ((process) && (board->Touch.FingerState[t]))
                        process = usb_activ_check_touch_distance(board, x, y, t);

                }
                else
                    if (board->Calibration.mode == CALIBRATION_MODE_TOUCH)
                    {
                        unsigned long now = 0;
                        process = FALSE;
                        now = jiffies;
                        now = jiffies_to_msecs(now);

                        // long)(((now - board->LastCommandTime)*1000)/HZ);
                        if (!board->Touch.FingerState[t])
                        {
                            board->Touch.FingerState[t] = 0x5;
                            board->Touch.LastClickTime = now;
                        }
                        else
                        {
                            if (board->Touch.LastClickTime)
                            {
                                if ((now - board->Touch.LastClickTime) > 1000)
                                {
                                    board->xyz.x = x;
                                    board->xyz.y = y;
                                    board->Touch.LastClickTime = 0;

                                    usb_activ_request_next_calib_point(board);
                                }
                            }
                        }
                    }


                if (!process && readRadiusData)
                {
                    if (radius != board->Touch.Last[t].Radius)
                    {
                        process = true;
                    }
                }
            }
            else
            {
                process = TRUE;
            }

            if (process)
            {
                if (privateTouch)
                {
                    // also set the touch bit (high bit)
                    privateData[privateDataSize++] = (t | 0x80);
                    privateData[privateDataSize++] = x & 0xff;
                    privateData[privateDataSize++] = (x >> 8) & 0xff;
                    privateData[privateDataSize++] = y & 0xff;
                    privateData[privateDataSize++] = (y >> 8) & 0xff;
                    privateData[privateDataSize++] = radius & 0xff;
                    privateData[privateDataSize++] = (radius >> 8) & 0xff;
                }


                if (!board->Touch.FingerState[t])
                {
                    DebugPrint(TRACE_LEVEL_INFORMATION, DRV_DBG_BOARD_DATA, (KERN_INFO "Promethean: Touch down %d at %d,%d\n", t, x, y));

                    board->Touch.LastClick[t].X = x;
                    board->Touch.LastClick[t].Y = y;

                    board->Touch.FingerState[t] = 0x5; // prox and click
                }

                if (systemTouch)
                {
                    if (!down_interruptible(&board->xinput_sem))
                    {
                        if ((board->x11open == X11_OPEN) && board->initialised)
                        {
#if USE_MT_API
                            input_mt_slot(dev,t);
                            if (board->Touch.Last[t].TrackingID < 0)
                                board->Touch.Last[t].TrackingID = (board->Touch.Last[t].TrackingID + 1) % MAX_TRACKING_ID;

                            input_report_abs(dev, ABS_MT_TRACKING_ID, board->Touch.Last[t].TrackingID);

                            //if (readRadiusData)
                            input_report_abs(dev, ABS_MT_TOUCH_MAJOR, (radius * board->Touch.RadiusUnit));

                            input_report_abs(dev, ABS_MT_POSITION_X, x);
                            input_report_abs(dev, ABS_MT_POSITION_Y, y);
#endif
                            syncX = TRUE;
                            if (t == 0)
                                moveX = TRUE;


                        }
                        up(&board->xinput_sem);
                    }

                    board->Touch.SystemFingerState[t] = 0x5;
                }

                board->Touch.Last[t].X = x;
                board->Touch.Last[t].Y = y;
                board->Touch.Last[t].Radius = radius;
            }
        }
        // 0xfff,0xfff
        else
        {

            // went from touch to untouch: clear click and prox
            if ((board->Touch.FingerState[t] & 0x1)||(board->Touch.SystemFingerState[t] & 0x1))
            {
                DebugPrint(TRACE_LEVEL_INFORMATION, DRV_DBG_BOARD_DATA, (KERN_INFO "Promethean: Touch up %d at %d,%d\n", t, x, y));

                if (privateTouch)
                {
                    // clear the touch bit (high bit)
                    privateData[privateDataSize++] = t;
                    privateData[privateDataSize++] = board->Touch.Last[t].X & 0xff;
                    privateData[privateDataSize++] = (board->Touch.Last[t].X >> 8) & 0xff;
                    privateData[privateDataSize++] = board->Touch.Last[t].Y & 0xff;
                    privateData[privateDataSize++] = (board->Touch.Last[t].Y >> 8) & 0xff;
                    privateData[privateDataSize++] = 0;
                    privateData[privateDataSize++] = 0;
                }

                if (systemTouch)
                {
                    if (!down_interruptible(&board->xinput_sem))
                    {
                        if ((board->x11open == X11_OPEN) && board->initialised)
                        {

#if USE_MT_API
                            input_mt_slot(dev,t);
                            board->Touch.Last[t].TrackingID = -1;

                            input_report_abs(dev, ABS_MT_TRACKING_ID, board->Touch.Last[t].TrackingID);
                            //input_report_abs(dev, ABS_MT_TOUCH_MAJOR, 0);
                            input_report_abs(dev, ABS_MT_POSITION_X, board->Touch.Last[t].X);
                            input_report_abs(dev, ABS_MT_POSITION_Y, board->Touch.Last[t].Y);
#endif

                            syncX = TRUE;
                        }
                        up(&board->xinput_sem);
                    }
                    board->Touch.SystemFingerState[t] = 0; // no prox and no click
                }

                board->Touch.FingerState[t] = 0; // no prox and no click
            }
            //board->Touch.Last[t].X = x;
            //board->Touch.Last[t].Y = y;
            board->Touch.Last[t].Radius = 0;
        }
    }


    if (systemTouch)
    {
        for (t = 0; t < touches; t++)
        {
            if (board->Touch.SystemFingerState[t] & 0x1)
                fingersDown++;
        }

        touches  = 1;
        if (fingersDown != fingersDownStart)
        {
            DebugPrint(TRACE_LEVEL_INFORMATION, DRV_DBG_BOARD_DATA, (KERN_INFO "Promethean: TOUCH ON fingersDown %d at %d,%d\n", fingersDown, board->Touch.Last[0].X, board->Touch.Last[0].Y));
            if (fingersDown <= 1) // send BTN_TOUCH only when going 0 -> 1 or more than 1->0
            {
                input_report_key(dev, BTN_TOOL_FINGER, fingersDown > 0);
                input_report_key(dev, BTN_LEFT, 1);
                syncX = TRUE;
            }
            /* it seems the first touch goes missing, so send it twice, at least until we know what's causing it ! */
            touches = 2;
        }

        if (moveX)
        {
            DebugPrint(TRACE_LEVEL_INFORMATION, DRV_DBG_BOARD_DATA, (KERN_INFO "Promethean: MOVE fingersDown %d at %d,%d\n", fingersDown, board->Touch.Last[0].X, board->Touch.Last[0].Y));
            for (t=0;t<touches;t++)
            {
                /*
                 * if (board->xyz.x == x)
                    board->Touch.Last[0].X++;
                if (board->xyz.y == y)
                    board->Touch.Last[0].Y++;
                board->xyz.x = board->Touch.Last[0].X;
                board->xyz.y = board->Touch.Last[0].Y;
*/
                input_report_abs(dev, ABS_X, board->Touch.Last[0].X);
                input_report_abs(dev, ABS_Y, board->Touch.Last[0].Y);
                input_sync(dev);
            }
            syncX = 0;
        }

        if ((fingersDown != fingersDownStart) && (!fingersDown))
        {
            DebugPrint(TRACE_LEVEL_INFORMATION, DRV_DBG_BOARD_DATA, (KERN_INFO "Promethean: TOUCH OFF fingersDown %d at %d,%d\n", fingersDown, board->Touch.Last[0].X, board->Touch.Last[0].Y));
            input_report_key(dev, BTN_LEFT, 0);
            input_report_key(dev, BTN_TOOL_FINGER, fingersDown > 0);
            syncX = TRUE;
        }

        if (syncX)
        {
            DebugPrint(TRACE_LEVEL_INFORMATION, DRV_DBG_BOARD_DATA, (KERN_INFO "Promethean: SYNC fingersDown %d at %d,%d\n", fingersDown, board->Touch.Last[0].X, board->Touch.Last[0].Y));
            input_sync(dev);
        }
    }

    if (privateTouch && (privateDataSize > 2)) // >= 2 means it has more than just the header
    {
        privateData[0] = privateDataSize;
        usb_activ_append_file_data(board, privateData, privateDataSize);
    }
}


/*
* usb_activ_decode_packet: decode the logical packets into either X11 coordinates / pressure
* or private data.
*/
static void usb_activ_decode_packet(struct usb_activ_device* board,
                                    struct pt_regs *regs, unsigned char *data, unsigned int length)
{
    unsigned char type = data[1], tempData[32];
    unsigned char process = FALSE;
    unsigned int len;
    struct input_dev *dev = board->x11dev;

    DebugPrint(TRACE_LEVEL_MEGAVERBOSE,DRV_DBG_BOARD_DATA,(KERN_INFO "Promethean: Received %02x\n",type));

    switch (type)
    {
    case 0x91:
        DebugPrint(TRACE_LEVEL_RELEASE,DRV_DBG_BOARD_DATA,(KERN_INFO "Promethean: received generic USB board message\n"));
        break;
    case CB_AC4_COORD_DATA:
    case CB_AC4_SYSTEM_COORD_DATA:
        usb_activ_process_touch(board, data, length);
        break;
    case CB_AC3_EXT_COORD:
    {
        if (!dev)
            break;

        // this is a compound packet, with coord and pressure in one.
        // Split it into its two components and call recursively.
        len = data[0];

        if (len <= sizeof(tempData))
        {
            memcpy(tempData, data, len);

            tempData[1] = CB_COORD_PEN1;
            switch (len)
            {
            case 0xc:
                len = 8;
                break;
            case 0xd: // later firmware with coord counter
                len = 9;
                tempData[8] = data[0xc];
                break;
            }

            tempData[0] = len;
            usb_activ_decode_packet(board, regs, tempData, len);

        }
        else
        {
            DebugPrint(TRACE_LEVEL_CRITICAL,DRV_DBG_BOARD_DATA,(KERN_INFO "Promethean: coordinate packet has grown too big (%d)\n", len));
        }
    }
        break;
    case CB_2_4_GENERAL:
        if ((data[0] < 0x20) || (__DBG_LEVEL >= TRACE_LEVEL_INFORMATION))
            usb_activ_append_file_data(board, data, length);
        break;
    case CB_COORD_PEN1:
    case CB_RF_PIC_SLATE_COORD:
    {
        unsigned short pen_or_slate_id = 0;
        unsigned char btn_state = data[7];
        //input_report_key(dev, BTN_LEFT,   data[7] & 0x01);
        //input_report_key(dev, BTN_RIGHT,  data[7] & 0x02);
        // input_report_key(dev, BTN_MIDDLE, data[0] & 0x04);
        //input_report_key(dev, BTN_SIDE,   data[0] & 0x08);
        // input_report_key(dev, BTN_EXTRA,  data[0] & 0x10);

        unsigned short x, y, original_x, original_y;
        const unsigned char slate = data[1]==CB_RF_PIC_SLATE_COORD;
        unsigned char privatePen = TRUE, publicPen = TRUE;
        unsigned char mode = 0;

        if (!dev)
            break;

        if (slate)
            pen_or_slate_id = data[2] & 0x7f;
        else // Pen
            pen_or_slate_id = (data[7]>>3) & 0xf;

        if (pen_or_slate_id) pen_or_slate_id--;
        pen_or_slate_id = pen_or_slate_id % (slate?MAX_ACTIV_SLATES:MAX_ACTIV_PENS_PER_BOARD);

        /* This can change the pen, slate or touch mode, so check before we store the mode */
        usb_activ_check_private_data_clients(board);

        if (slate)
            mode = board->SlatePenMode[pen_or_slate_id];
        else
            mode = (board->BoardPenMode >> (pen_or_slate_id*2)) & 0x3;

        privatePen = (mode == DEST_APP) || (mode == DEST_OS_APP);
        publicPen = (mode == DEST_OS_APP) || (mode == DEST_OS);

        process = privatePen || publicPen;

        x = le16_to_cpu(*(__le16 *) &data[3]);
        y = le16_to_cpu(*(__le16 *) &data[5]);

        if ((x & 0x8000) && (y & 0x8000) && (btn_state & 0x1) && (btn_state & 0x4)) {
            /* click on logo */
            data[0] = 7;
            data[1] = CB_GENERAL;
            data[2] = 'C';
            data[3] = 'A';
            data[4] = 'L';
            data[5] = 'I';
            data[6] = 'B';

            usb_activ_append_file_data(board, data, data[0]);
            process = FALSE; // no need to process data any further
        }


        if ((data[0] == 0x9) // coord with packet counter (ac3 wired)
                ||
                ((data[1] == CB_AC3_EXT_COORD) && (data[0] == 0xd))) // ac3 wireless with packet counter
        {
            if (!slate)
            {
                long currentCounter = data[data[0]-1], qCounter = 0;

                if (board->LastCoordCounter >= 0)
                {
                    long expected = (board->LastCoordCounter + 1) % 0x100, p = 0;
                    unsigned char coord[0xff];

                    // if one of the queued up packets is expected, we queue up.
                    for (p = 0; p < MAX_MISSED_PACKETS; p++)
                    {
                        if (board->MissedCoords[p][0] == 0) // not a valid coord
                            break;

                        qCounter = board->MissedCoords[p][data[0] - 1];

                        if (qCounter == expected)
                        {
                            if (board->MissedCoordsCount > 1)
                                DebugPrint(TRACE_LEVEL_CRITICAL,DRV_DBG_BOARD_DATA,(KERN_INFO "Promethean: current 0x%02lx but found expected packet %ld/0x%02lx in queue (sz=%ld)!\n",
                                                                                    currentCounter,expected, expected,
                                                                                    board->MissedCoordsCount));

                            // copy the packet first
                            memcpy(coord, board->MissedCoords[p], board->MissedCoords[p][0]);

                            // invalidate the packet in the queue (otherwise the recursive call will loop for ever)
                            board->MissedCoords[p][0] = 0;
                            board->MissedCoordsCount--;


                            // recursive call !!!!
                            usb_activ_decode_packet(board, regs, coord, coord[0]);

                            // work it out again, in case we modified it
                            expected = (board->LastCoordCounter + 1) % 0x100;
                        }
                    }

                    if (currentCounter == expected)
                    {
                        board->LastCoordCounter = currentCounter;
                    }
                    else
                    {
                        process = FALSE;

                        if (board->MissedCoordsCount > 1)
                            DebugPrint(TRACE_LEVEL_CRITICAL,DRV_DBG_BOARD_DATA,(KERN_INFO "Promethean: queueing coordinate: %ld/0x%02lx received, expected %ld/0x%02lx\n",
                                                                                currentCounter, currentCounter,
                                                                                expected, expected));

                        if (board->MissedCoordsCount < MAX_MISSED_PACKETS)
                        {
                            for (p = 0; p < MAX_MISSED_PACKETS; p++)
                            {
                                if (board->MissedCoords[p][0] == 0) // empty location
                                {
                                    memcpy(board->MissedCoords[p], data, data[0]);
                                    board->MissedCoordsCount++;
                                    break;
                                }
                            }
                        }
                        else
                        {
                            DebugPrint(TRACE_LEVEL_CRITICAL,DRV_DBG_BOARD_DATA,(KERN_INFO  "Promethean: #ERROR: Too many queued coordinates in buffer (%ld): resetting current coordinate.\n",
                                                                                board->MissedCoordsCount));

                            // this is no longer an error: we restart from the current one.
                            board->MissedCoordsCount = 0;
                            memset(board->MissedCoords,0,sizeof(board->MissedCoords));
                            board->LastCoordCounter = currentCounter;
                            process = TRUE;
                        }
                    }
                }
                else
                {
                    // initial setup
                    board->LastCoordCounter = currentCounter;
                }
            }
        }

        if (process)
            process = usb_activ_calibrate(board, x, y, &x, &y, slate);

        if (process) {

            original_x = x;
            original_y = y;

            if ((btn_state & 0x7) == (board->LastButtonState[pen_or_slate_id] & 0x7))
                process = usb_activ_check_distance(board,x,y,pen_or_slate_id);

            if ((process) && (!board->Calibration.mode)) {

                if (privatePen) {
                    /* modify the packet : x and y contain the calibrated data */

                    // store original length
                    u8 len = data[0];
                    data[0] = 0x8; // ActivSystem cannot cope with coords being either 8 or 9 bytes, it only understands 8.
                    // On AC3 the packet length is 9, but we can safely strip the last byte (data counter)
                    data[3] = x & 0xff;
                    data[4] = (x>>8) & 0xff;
                    data[5] = y & 0xff;
                    data[6] = (y>>8) & 0xff;
                    usb_activ_append_file_data(board, data, data[0]);

                    // restore original length
                    data[0] = len;
                }

                board->LastX[pen_or_slate_id] = original_x;
                board->LastY[pen_or_slate_id] = original_y;
            }

            if (process) {
                if (publicPen || board->Calibration.mode) {
                    if (!down_interruptible(&board->xinput_sem)) {
                        if ((board->x11open == X11_OPEN) && board->initialised) {

                            // it looks like X ignores button info if prox is toggled, so send prox separately.
                            // this is prox off to on.
                            if (((btn_state & 4) != (board->LastButtonState[pen_or_slate_id] & 4)) && (btn_state & 4))
                            {
                                // force a touch up, must unlock first
                                up(&board->xinput_sem);
                                usb_activ_send_touch_packet_to_system(board,NULL);

                                // relock
                                if (!down_interruptible(&board->xinput_sem)) {
                                    input_report_key(dev, BTN_TOOL_PEN,    (data[7] & 4)?1:0);
                                    input_sync(dev);
                                }
                            }


#ifdef _PRE_2_6_18_
                            input_regs(dev, regs);
#endif
                            /*
                In calibration mode, we do not send anything. We send a message via the private stream to say "advance to next point".
                We used to send a fixed coord to max/2, max/2, but that doesn't work with all screen configurations, and you may end up in
                a dead area (one without a window, and the calib never notices the click.
                */

                            if (board->Calibration.mode == CALIBRATION_MODE_OFF)
                            {

                                /*if (board->xyz.x == x)
                                    x++;
                                if (board->xyz.y == y)
                                    y++;
                                board->xyz.x = x;
                                board->xyz.y = y;*/

                                DebugPrint(TRACE_LEVEL_VERBOSE,DRV_DBG_BOARD_DATA,(KERN_INFO  "Promethean: Sending to X11 x y (%d,%d)\n", x,y));
                                input_report_abs(dev, ABS_X,     x);
                                input_report_abs(dev, ABS_Y,     y);

                                if ((btn_state & 1) != (board->LastButtonState[pen_or_slate_id] & 1))
                                {
                                    DebugPrint(TRACE_LEVEL_INFORMATION,DRV_DBG_BOARD_DATA,(KERN_INFO  "Promethean: Left button %s\n",(data[7] & 0x1)?"down":"up"));
                                    input_report_key(dev, BTN_LEFT,     (data[7] & 0x1)?0x1:0x0);
                                }
                                else
                                    if ((btn_state & 2) != (board->LastButtonState[pen_or_slate_id] & 2))
                                    {
                                        DebugPrint(TRACE_LEVEL_INFORMATION,DRV_DBG_BOARD_DATA,(KERN_INFO  "Promethean: Right button %s\n",(data[7] & 0x2)?"down":"up"));
                                        input_report_key(dev, BTN_RIGHT,   (data[7] & 0x2)?0x1:0x0);
                                    }
                                input_sync(dev);

                                // it looks like X ignores button info if prox is toggled, so send prox separately.
                                // this is prox on to off.
                                if (((btn_state & 4) != (board->LastButtonState[pen_or_slate_id] & 4)) && (!(btn_state & 4)))
                                {
                                    input_report_key(dev, BTN_TOOL_PEN,    (data[7] & 4)?1:0);
                                    input_sync(dev);
                                }
                            }
                            else
                            {
                                unsigned long now = 0;
                                now = jiffies;
                                now = jiffies_to_msecs(now);

                                if ((btn_state & 1) != (board->LastButtonState[pen_or_slate_id] & 1))
                                {
                                    if (btn_state & 1) // button down
                                    {

                                        switch (board->Calibration.mode)
                                        {
                                        case CALIBRATION_MODE_ON:
                                            // request next point
                                            usb_activ_request_next_calib_point(board);
                                            break;
                                        case CALIBRATION_MODE_SELECT:
                                            // store button down time
                                            board->LastClickTime[0] = now;
                                            break;
                                        }
                                    }
                                    else // button up
                                    {
                                        switch (board->Calibration.mode)
                                        {
                                        case CALIBRATION_MODE_ON:
                                            // do nothing
                                            break;
                                        case CALIBRATION_MODE_SELECT:
                                            // store button down time
                                            if (board->LastClickTime[0])
                                                if ((now - board->LastClickTime[0]) < 2000)
                                                    usb_activ_request_next_calib_point(board);

                                            break;
                                        }
                                    }

                                }
                                else
                                    if ((btn_state & 1) == (board->LastButtonState[pen_or_slate_id] & 1))
                                    {
                                        if (btn_state & 1)
                                        {
                                            switch (board->Calibration.mode)
                                            {
                                            case CALIBRATION_MODE_SELECT:
                                                // store button down time
                                                if (board->LastClickTime[0])
                                                    if ((now - board->LastClickTime[0]) > 2000)
                                                    {
                                                        board->LastClickTime[0] = 0;
                                                        usb_activ_request_screen_selection(board);
                                                    }

                                                break;
                                            }
                                        }
                                    }

                                if ((btn_state & 2) != (board->LastButtonState[pen_or_slate_id] & 2))
                                {
                                    if (! (btn_state & 2)) // button up
                                    {
                                        usb_activ_request_calib_quit(board);
                                    }
                                }
                            }
                        }
                        up(&board->xinput_sem);
                    }
                }
            }
        }

        if ((board->Calibration.mode) && (data[7] & 0x1)) {
            if ((btn_state & 0x1) != (board->LastButtonState[pen_or_slate_id] & 0x1)) {
                board->xyz.x = x;
                board->xyz.y = y;
            }
        }

        board->LastButtonState[pen_or_slate_id] = btn_state;
    }
        break;
    case CB_FIRMWARE_PACKET:
        usb_activ_append_file_data(board, data, length);
        break;
    default:
        switch (type)
        {
        case CB_GENERAL:
            if (!board->ReceivedOK)
                board->ReceivedOK = (data[0] >= 4) && (data[2]=='O') && (data[3] == 'K');
            break;
        case CB_2_4_RF_CHANGE_STATE:
            board->HubState = data[3];
            switch (board->HubState)
            {
            case 0x22: // self paced optimisation
                board->DelayWrites = 0;
                break;
            default:
                board->DelayWrites = 3;
                break;
            }
            break;
        case CB_2_4_DEVICES_INFO:
            if (length > 10)
                board->HubState = data[10];
            break;
        }

        usb_activ_append_file_data(board, data, length);
        break;
    }
}


/*
* usb_activ_process_incoming_data: rejoin or split the packets and send them to the correct destination, OS, or client
*/
static void usb_activ_process_incoming_data(struct usb_activ_device* board,
                                            struct pt_regs *regs,
                                            int pipe,
                                            unsigned char *data, unsigned int length)
{
    if (!down_interruptible(&board->data_processor_sem)) {
        int i= 0;

        if (data[0] != length) {
            DebugPrint(TRACE_LEVEL_VERBOSE,DRV_DBG_BOARD_DATA, (KERN_INFO "Promethean: Split or multiple packet[%d]: len %d - hdr len %d\n", pipe, length, data[0]));
        }

        for (i = 0; i < length; i++) {
            // no pending data: we're at the beginning of a packet
            if (!board->RemainingPacketSize[pipe]) {
                if (data[i]) {
                    board->CompletedPacketSize[pipe] = data[i];
                    board->RemainingPacketSize[pipe] = data[i];
                    board->CompletedPacketIndex[pipe] = 0;
                } else {
                    DebugPrint(TRACE_LEVEL_CRITICAL,DRV_DBG_BOARD_DATA, (KERN_INFO "Promethean: ERROR: PACKET WITH NO LENGTH\n"));
                }
            }

            // build up the data packet
            if (board->RemainingPacketSize[pipe]) {
                board->CompletedPacket[pipe][board->CompletedPacketIndex[pipe]++] = data[i];
                board->RemainingPacketSize[pipe]--;

                if (!board->RemainingPacketSize[pipe]) {
                    usb_activ_decode_packet(board,regs, board->CompletedPacket[pipe],board->CompletedPacketIndex[pipe]);
                    board->CompletedPacketIndex[pipe] = 0;
                }
                else if (board->CompletedPacketIndex[pipe] >= (MAX_PACKET_BUFFER_SIZE - 2)) {
                    char fake[MAX_PACKET_BUFFER_SIZE];
                    fake[0] = MAX_PACKET_BUFFER_SIZE;
                    fake[1] = CB_GENERAL;
                    memcpy(fake + 2, board->CompletedPacket[pipe], MAX_PACKET_BUFFER_SIZE -2);

                    DebugPrint(TRACE_LEVEL_CRITICAL,DRV_DBG_BOARD_DATA,(KERN_INFO "Promethean: A Packet on pipe %d is bigger than the maximum size of %d.\n",pipe,MAX_PACKET_BUFFER_SIZE));


                    usb_activ_append_file_data(board, fake, MAX_PACKET_BUFFER_SIZE);
                    board->CompletedPacketIndex[pipe] = 0;
                }
            }
        }
        up(&board->data_processor_sem);
    }
}

int usb_activ_thread_process_pipe_data(void *p)
{
    struct urb *urb = (struct urb *)p;
    struct usb_activ_device* board = (struct usb_activ_device*)urb->context;
    signed char *data = NULL;
    int ndx = -1;

    for (ndx = 0; ndx < MAX_INT_PIPES; ndx++)
    {
        if (urb == board->irq[ndx])
        {
            data = board->data_in[ndx];
            break;
        }
    }

    DebugPrint(TRACE_LEVEL_VERBOSE,DRV_DBG_BOARD_DATA,(KERN_INFO "Promethean: Started thread for pipe[%d]\n",ndx));

    if (ndx < MAX_INT_PIPES)
    {
        unsigned char running = TRUE;

        while (running) {
            if (!down_interruptible(&board->input_data_ready[ndx])) {

                struct pt_regs *regs = NULL;
                int status = 0;

                running = board->irq[ndx] != NULL;

                if (!running)
                    break;

                status = 0;
                if (urb->status < 0)
                {
                    /* get the endpoint status and reset it */
                    u16 data;
#if (LINUX_VERSION_CODE < KERNEL_VERSION(4,15,0))
                    status = usb_get_status(board->usbdev, USB_RECIP_ENDPOINT, board->pipe_in[ndx], (void*)&data);
#else
                    status = usb_get_std_status(board->usbdev, USB_RECIP_ENDPOINT, board->pipe_in[ndx], (void*)&data);
#endif
                    if (status >= 0)
                    {
                        /* USB Specification: endpoint status is returned as 2 bytes, bit 0 is halt status */
                        if ((data & 0x1) == 0x1)
                            usb_activ_reset_endpoint(board,board->pipe_in[ndx]);
                    }
                    else
                    {
                        DebugPrint(TRACE_LEVEL_CRITICAL,DRV_DBG_BOARD_DATA, (KERN_INFO "Promethean: Status Query Failed on Endpoint %d: %d\n", ndx, status));
                    }
                }
                else
                {
                    DebugPrint(TRACE_LEVEL_MEGAVERBOSE, DRV_DBG_BOARD_DATA,(KERN_INFO "Promethean: Processing %d bytes on [%d] %p\n",urb->actual_length,ndx,board->irq[ndx]));
                    usb_activ_process_incoming_data(board,regs,ndx,data,urb->actual_length);
                }

                /* something went wrong when getting the status, do not resubmit. */
                if (status >=0)
                    status = usb_submit_urb (urb, GFP_KERNEL);

                if (status) {
					DebugPrint(TRACE_LEVEL_CRITICAL, 
							DRV_DBG_BOARD_DATA,(KERN_INFO  "can't resubmit intr, %s-%s/input0, status %d",
                         board->usbdev->bus->bus_name,
                         board->usbdev->devpath, status));

                    running = FALSE;
                }
            }

            running = !kthread_should_stop();
        }

        up(&board->input_data_thread_end[ndx]);
    }
    DebugPrint(TRACE_LEVEL_VERBOSE,DRV_DBG_BOARD_DATA,(KERN_INFO "Promethean: No Longer Processing bytes on [%d]\n",ndx));

    do_exit(0);
    return 0;
}

/*
* usb_activ_irq: the URB callback. Raw USB data gets processed and sent to the right destination.
*/
#ifdef _PRE_2_6_18_
static void usb_activ_irq(struct urb *urb, struct pt_regs *regs)
#else
static void usb_activ_irq(struct urb *urb)
#endif
{
    struct usb_activ_device *board = urb->context;
    int status, ndx = 0;

    switch (urb->status)
    {
    case 0:			/* success */
        break;
    case -ENOENT:
    case -ESHUTDOWN:
    case -ECONNRESET:
        DebugPrint(TRACE_LEVEL_CRITICAL,DRV_DBG_BOARD_DATA,(KERN_INFO "Promethean: URB Completion Fatal Status : %d\n",urb->status));
        return;
        /* -EPIPE:  should clear the halt, but cannot be done in the irq (in interrupt context) */
    case -EPROTO:
        /* let the thread clear the pipe */
        DebugPrint(TRACE_LEVEL_CRITICAL,DRV_DBG_BOARD_DATA,(KERN_INFO "Promethean: URB Completion Possible Stall Status : %d\n",urb->status));
        break;
    default:		/* error */
        DebugPrint(TRACE_LEVEL_CRITICAL,DRV_DBG_BOARD_DATA,(KERN_INFO "Promethean: URB Completion Resubmit : %d\n",urb->status));
        goto resubmit;
    }

    for (ndx = 0; ndx < MAX_INT_PIPES; ndx++)
    {
        if (urb == board->irq[ndx]) {

            DebugPrint(TRACE_LEVEL_MEGAVERBOSE, DRV_DBG_BOARD_DATA,(KERN_INFO "Promethean: Msg from pipe %d: %d bytes\n", ndx, urb->actual_length));

            if (!ndx)
                if ((board) && (!board->initialised)) board->initialised = TRUE;

            up(&board->input_data_ready[ndx]);
            break;
        }
    }
    if (ndx >= MAX_INT_PIPES)
    {
        DebugPrint(TRACE_LEVEL_VERBOSE,DRV_DBG_BOARD_DATA,(KERN_INFO "Promethean: Msg from pipe ? CANCEL: %d bytes\n", urb->actual_length));
        goto resubmit;
    }

    /* usb_activ_process_incoming_data(board, regs, data, urb->actual_length);
can't call this : it is calling schedulable functions and we are in an irq.
Instead, wake up an event that will read the data from the irq and resubmit the urb.
*/

    return;


resubmit:
    status = usb_submit_urb (urb, GFP_ATOMIC);
    if (status)
    {
			DebugPrint(TRACE_LEVEL_CRITICAL, DRV_DBG_BOARD_DATA,(KERN_INFO "1/ can't resubmit intr, %s-%s/input0, status %d",
             board->usbdev->bus->bus_name,
             board->usbdev->devpath, status));
    }
}

/*
* usb_activ_reset_endpoint: reset endpoint after failed comms or at startup.
*/
static void usb_activ_reset_endpoint(struct usb_activ_device *board,int endpoint)
{
    DebugPrint(TRACE_LEVEL_CRITICAL,DRV_DBG_CONFIG,(KERN_INFO "Promethean: Reset pipe 0x%x\n",endpoint));
    usb_clear_halt(board->usbdev,endpoint);
}

/*
* AC3 does not boot properly if we reset the endpoints too early. So, schedule the initialise in a thread and wait first.
*/
int xinput_open_thread(void *p)
{
    struct usb_activ_device *board = (struct usb_activ_device *)p;

    if ((board) && (!board->initialised))
    {
        schedule_timeout_interruptible(msecs_to_jiffies(500));
        usb_activ_initialise_endpoints(board);
    }

    usb_activ_xinput_open_mode(board, X11_OPEN);

    do_exit(0);
    return 0;
}

static void usb_activ_send_touch_packet_to_system(struct usb_activ_device* board, TOUCH_PACKET *tp)
{
    u8 BoardPacket[0xff], SystemDataSize = 0, t = 0;
    const int coordOffset = 3;

    // generate a touch packet as if it came from the board and send it to Windows exclusively

    // 1 rebuild a michelangelo packet from the activsystem packet (without the radius)
    memset(BoardPacket, 0, sizeof(BoardPacket));
    BoardPacket[SystemDataSize++] = 0;

    // create the data as a CB_AC4_SYSTEM_COORD_DATA, not CB_AC4_COORD_DATA.
    // This way, we can call decodeusbpacket, wich will inject the data as if it came from the board
    // and not include the radius : processTouch will know to forward to the system only and not care about private.
    BoardPacket[SystemDataSize++] = CB_AC4_SYSTEM_COORD_DATA;
    BoardPacket[SystemDataSize++] = 1; // board ID

    for (t = 0;t < MAX_ACTIV_TOUCHES_PER_BOARD; t++)
    {
        BoardPacket[coordOffset + (t * 4)]	= 0xff;
        BoardPacket[coordOffset + (t * 4)+1]	= 0xff;
        BoardPacket[coordOffset + (t * 4)+2]	= 0xff;
        BoardPacket[coordOffset + (t * 4)+3]	= 0xff;
        SystemDataSize+=4;
    }

    if (tp)
    {
        for (t = 0; t < MAX_ACTIV_TOUCHES_PER_BOARD; t++)
        {
            // data is : (ID (byte), X,Y,Radius as shorts) * number of touches
            if (tp->data[t].ID != 0xff)
            {
                if (tp->data[t].ID & 0x80) // hi-bit set means touch, not set means touch up
                {
                    DebugPrint(TRACE_LEVEL_CRITICAL,DRV_DBG_CONFIG,(KERN_INFO "Promethean: System coord %d %d,%d\n",tp->data[t].ID,tp->data[t].x,tp->data[t].y));

                    BoardPacket[coordOffset + (tp->data[t].ID & 0x7f) * 4]     = tp->data[t].x & 0xff;
                    BoardPacket[coordOffset + (tp->data[t].ID & 0x7f) * 4 + 1] = (tp->data[t].x>>8) & 0xff;
                    BoardPacket[coordOffset + (tp->data[t].ID & 0x7f) * 4 + 2] = tp->data[t].y & 0xff;
                    BoardPacket[coordOffset + (tp->data[t].ID & 0x7f) * 4 + 3] = (tp->data[t].y>>8) & 0xff;
                }
            }
        }
    }


    BoardPacket[0] = SystemDataSize;

    // 2 process this touch (remember to force system only)
    if (tp)
    {
        if (!down_interruptible(&board->data_processor_sem))
        {
            usb_activ_decode_packet(board,NULL,BoardPacket , BoardPacket[0]);
            up(&board->data_processor_sem);
        }
    }
    else // this is sent with the semaphore already owned
        usb_activ_decode_packet(board,NULL,BoardPacket , BoardPacket[0]);

}

/*
* usb_activ_xinput_activ_open: X11 wants us.
*/
static int usb_activ_xinput_activ_open(struct input_dev *dev)
{
#ifdef _PRE_2_6_18_
    struct usb_activ_device *board = dev->private;;
#else
    struct usb_activ_device *board = input_get_drvdata(dev);
#endif

    DebugPrint(TRACE_LEVEL_CRITICAL,DRV_DBG_INIT,(KERN_INFO "Promethean: X11 Open.\n"));

    usb_activ_xinput_open_mode(board, X11_PENDING);
    usb_activ_xinput_open_mode(board, X11_OPEN);

    // kthread_run(xinput_open_thread, board,"Open X11");

    DebugPrint(TRACE_LEVEL_VERBOSE,DRV_DBG_INIT,(KERN_INFO "Promethean: Exit X11 Open.\n"));

    return 0;
}

/*
* usb_activ_xinput_activ_close: X11 no longer wants data from us.
* Closing the handles here means we can't use activconsole from a terminal outside X.
*/
static void usb_activ_xinput_activ_close(struct input_dev *dev)
{
#ifdef _PRE_2_6_18_
    struct usb_activ_device *board = dev->private;
#else
    struct usb_activ_device *board = input_get_drvdata(dev);
#endif

    usb_activ_xinput_open_mode(board, X11_CLOSED);
}

/*
* usb_activ_write: Write buffer to bulk pipe.
*/
static ssize_t usb_activ_write(struct usb_activ_device *board,const char *user_buffer, size_t count,
                               const unsigned char is_user_buffer, const unsigned char wait)
{
    int retval = 0;
    struct urb *urb = NULL;
    char *buf = NULL;
    size_t writesize = min(count, board->max_bulk_transfer_size);
    unsigned long now = 0;
    long elapsed = 0;
    long AcceptableDelay = board->DelayWrites;

    if (down_interruptible(&board->limit_sem))
        return -ERESTARTSYS;

    /* cannot write too quickly, need to wait 25 ms for AC1, AC2 and old hub.
     * 2.4 hub do not have this problem */
    if (AcceptableDelay)
    {
        // make sure it is a multiple of ms in jiffies
        if (AcceptableDelay % (1000/HZ))
            AcceptableDelay = (AcceptableDelay / (1000/HZ)) + 1000/HZ;

        now = jiffies;

        if (now >= board->LastCommandTime)
            elapsed = (long)(((now - board->LastCommandTime)*1000)/HZ);
        else
        {
            elapsed = (long)(((board->LastCommandTime - now)*1000)/HZ);
            if (elapsed > AcceptableDelay)
            {
                AcceptableDelay	= elapsed;
                elapsed = 0;

                if (AcceptableDelay	> 2000)
                    AcceptableDelay	 = 2000;
            }
        }

        if (elapsed < AcceptableDelay)
        {
            long w = ((AcceptableDelay - elapsed) *  HZ)/1000;
            DebugPrint(TRACE_LEVEL_INFORMATION,DRV_DBG_INIT,(KERN_INFO "Promethean: Delaying by %ld jiffies, %ld out of %ld ms.\n", w, elapsed, AcceptableDelay));

            if (w > 0)
            {
                schedule_timeout_interruptible(w);
            }
        }
        board->LastCommandTime = jiffies;
    }


    board->write_urb = usb_alloc_urb(0, GFP_ATOMIC);
    urb = board->write_urb;

    if (!urb) {
        retval = -ENOMEM;
        goto error;
    }

    buf = usb_alloc_coherent(board->usbdev, writesize+1, GFP_ATOMIC, &urb->transfer_dma);
    if (!buf) {

        retval = -ENOMEM;
        goto error;
    }

    if (is_user_buffer) {
        if (copy_from_user(buf, user_buffer, writesize)) {
            retval = -EFAULT;
            goto error;
        }
    }
    else {
        if (!memcpy(buf, user_buffer, writesize)) {

            retval = -EFAULT;
            goto error;
        }
    }

    buf[writesize]=0; /* 0 terminate, software has a habit of not doing this !*/
    if (writesize > 3)
    {
        if (!memcmp(buf,":SF\r",4))
        {
            board->FirmwareUpgradeMode = TRUE;
        }
        else
            if (!memcmp(buf,":FU\r",4))
                board->FirmwareUpgradeMode = TRUE;
            else
                if (!memcmp(buf,":ED\r",4))
                    board->FirmwareUpgradeMode = FALSE;
                else
                    if ((!memcmp(buf,":CD",3)) && (buf[writesize-1]=='\r'))
                        board->FirmwareUpgradeMode = TRUE;
    }

    usb_fill_bulk_urb(urb, board->usbdev,
                      board->pipe_out[board->lastOutPipe],
                      buf, writesize, usb_activ_file_write_bulk_callback, board);
    urb->transfer_flags |= URB_NO_TRANSFER_DMA_MAP;

    if (board->FirmwareUpgradeMode)
    {
        DebugPrint(TRACE_LEVEL_INFORMATION,DRV_DBG_USER_DATA,(KERN_INFO "Promethean: Sending FW Upgrade Packet %ld bytes.\n",(long)writesize));
    }
    else
    {
        if (writesize < 32 )
        {
            /*
* We can't just dump the command, it can corrupt dmesg.
*/
            char smallcomm[32];
            int c = 0;
            for (c = 0; c < writesize; c++)
            {
                if (buf[c] == '\r')
                {
                    smallcomm[c] = 0;
                    break;
                }
                else
                    smallcomm[c] = buf[c];
            }
            DebugPrint(TRACE_LEVEL_RELEASE,DRV_DBG_USER_DATA,(KERN_INFO "Promethean: Sending Command %s from pid %d on enpoint %d/%d\n",smallcomm,current->pid,board->lastOutPipe, board->numOutPipes));
        }
        else
        {
            DebugPrint(TRACE_LEVEL_RELEASE,DRV_DBG_USER_DATA,(KERN_INFO "Promethean: Sending Large Command %ld bytes.\n",(long)writesize));
        }
    }

    /* BEWARE: it is not safe to use buf AFTER the urb was sent: it get deleted by
the urb completion in parallel. */
    if (((!memcmp(buf,":UR",3)) && (buf[writesize-1]=='\r'))
            ||
            ((!memcmp(buf,":CS",3)) && (buf[writesize-1]=='\r')))
    {
        // renumbered the board, we need to inform all clients, in particular activmanager.
        unsigned char data[3];
        data[0] = 3;
        data[1] = CB_REENUMERATE;
        data[2] = CHANGE_BOARD_ID;

        usb_activ_append_file_data(board, data, data[0]);
    }

    /* send the data out the bulk port */
    retval = usb_submit_urb(urb, wait?GFP_KERNEL:GFP_ATOMIC);

    /* BEWARE: it is not safe to use buf after this call: it gets deleted in the completion routine. */

    if (retval) {
        DebugPrint(TRACE_LEVEL_CRITICAL,DRV_DBG_USER_DATA,(KERN_INFO "Promethean: Error [%d] sending %ld bytes.\n",retval,(long)writesize));
        goto error;
    }

    /* usb_free_urb(urb); */
    if (wait) waitForWriteCompletion(board);

    return writesize;

error:
    if (buf) usb_free_coherent(board->usbdev, writesize, buf, urb->transfer_dma);
    if (urb) usb_free_urb(urb);
    up(&board->limit_sem);
    return retval;
}

/*
usb_activ_probe: device plugged in. Initialise endpoint data and urbs.
Initialise the board object and allocate endpoint data for INT urbs.

USB Board V2, V3, V8 : 1 INT endpoint, 1 Bulk endpoint
USB Hub   V4 	     : 1 INT endpoint, 1 Bulk endpoint
USB 2.4 gHz Hub V5   : 2 INT endpoint, 1 Bulk endpoint
*/

static int usb_activ_probe(struct usb_interface *intf, const struct usb_device_id *id)
{
    struct usb_device *dev = interface_to_usbdev(intf);
    struct usb_host_interface *interface;
    struct usb_endpoint_descriptor *endpoint;
    struct usb_activ_device *board;
    struct input_dev *input_dev;
    int e, inpipe[MAX_INT_PIPES], outpipe[MAX_BULK_PIPES],maxp = 64,retval,p,
            inpipe_count = 0, inpipe_to_endpoint[MAX_INT_PIPES],
            outpipe_count = 0, outpipe_to_endpoint[MAX_BULK_PIPES],
            max_bulk_transfer_size = 64;

    for (e = 0; e < MAX_INT_PIPES; e++)
    {
        inpipe[e] = 0;
        inpipe_to_endpoint[e] = 0;
    }

    for (e = 0; e < MAX_BULK_PIPES; e++)
    {
        outpipe[e] = 0;
        outpipe_to_endpoint[e] = 0;
    }

    interface = intf->cur_altsetting;

    if (interface->desc.bNumEndpoints > 7) {
        DebugPrint(TRACE_LEVEL_CRITICAL,DRV_DBG_INIT,(KERN_INFO "Promethean: Wrong number of endpoints: %d\n",interface->desc.bNumEndpoints));
        return -ENODEV;
    }


    for (e = 0; e < interface->desc.bNumEndpoints; e++)
    {
        endpoint = &interface->endpoint[e].desc;

        if (((endpoint->bEndpointAddress & USB_ENDPOINT_DIR_MASK)  == USB_DIR_IN) &&
                ((endpoint->bmAttributes & USB_ENDPOINT_XFERTYPE_MASK) == USB_ENDPOINT_XFER_INT))
        {
            inpipe[inpipe_count] = usb_rcvintpipe(dev, endpoint->bEndpointAddress);

            inpipe_to_endpoint[inpipe_count] = e;
            inpipe_count++;

            if (inpipe_count == 1)
                maxp = usb_maxpacket(dev, inpipe[0], usb_pipeout(inpipe[0])) * 5;
        }
        else
            if (((endpoint->bEndpointAddress & USB_ENDPOINT_DIR_MASK)  == USB_DIR_OUT) &&
                    ((endpoint->bmAttributes & USB_ENDPOINT_XFERTYPE_MASK) == USB_ENDPOINT_XFER_BULK))
            {
                outpipe[outpipe_count] = usb_sndbulkpipe(dev, endpoint->bEndpointAddress);

                outpipe_to_endpoint[outpipe_count] = e;
                outpipe_count++;

                if (outpipe_count == 1)
                    max_bulk_transfer_size = endpoint->wMaxPacketSize;
            }
    }

    board = kzalloc(sizeof(struct usb_activ_device), GFP_KERNEL);

    board->idProduct = dev->descriptor.idProduct;
    switch (dev->descriptor.idProduct)
    {
    case 6:
        input_dev = NULL; // project X does not require to interface with X
        break;
    default:
        input_dev = input_allocate_device();
        if (!input_dev)
            goto fail;
        break;
    }


    if (!board)
        goto fail;

    memset(board,0,sizeof(struct usb_activ_device));
    board->DoubleClickDelay = 350;
    board->DoubleClickDistance = 3;
    board->Timeout = HZ * 5; /* 5 second timeout by default */
    board->LastCoordCounter = -1;
    /* Good value in case board was not calibrated */
    board->Calibration.OnePixelX = 25;
    board->Calibration.OnePixelY = 31;
    board->FirmwarePenState.PressureLevels = 2;
#if (LINUX_VERSION_CODE < KERNEL_VERSION(4,15,0))
    init_timer(&board->FirmwarePenState.timer);
    board->FirmwarePenState.timer.function = penStateTimerCallback;
    board->FirmwarePenState.timer.data = (unsigned long)board;
#else
    timer_setup(&board->FirmwarePenState.timer, penStateTimerCallback, 0);
#endif
    board->Touch.Enabled = TRUE;
    board->Touch.SystemRedirectionEnabled = TRUE;
    board->max_bulk_transfer_size = max_bulk_transfer_size;
    DebugPrint(TRACE_LEVEL_RELEASE,DRV_DBG_INIT,(KERN_INFO "Promethean: max write size: %d\n", (int)board->max_bulk_transfer_size));

    board->maxp = maxp;
    board->usbdev = dev;

    for (p = 0 ; p < outpipe_count; p++)
    {
        board->pipe_out[p]= outpipe[p];
    }
    board->numOutPipes = outpipe_count;

    for (p = 0 ; p < inpipe_count; p++) {
        board->pipe_in[p] = inpipe[p];
        board->data_in[p] = usb_alloc_coherent(dev, maxp, GFP_ATOMIC, &board->data_in_dma[p]);

        if (!board->data_in[p])
            goto fail;

        board->irq[p] = usb_alloc_urb(0, GFP_KERNEL);
        if (!board->irq[p])
            goto fail;

        usb_fill_int_urb(board->irq[p], dev, board->pipe_in[p], board->data_in,
                         maxp,
                         usb_activ_irq, board, interface->endpoint[inpipe_to_endpoint[p]].desc.bInterval);

        DebugPrint(TRACE_LEVEL_VERBOSE,DRV_DBG_INIT,(KERN_INFO "Promethean: Interval for pipe %d is %d\n",inpipe_to_endpoint[p],interface->endpoint[inpipe_to_endpoint[p]].desc.bInterval));
        board->irq[p]->transfer_dma = board->data_in_dma[p];
        board->irq[p]->transfer_flags |= URB_NO_TRANSFER_DMA_MAP;
    }

    board->DelayWrites = 0;
    board->x11dev = input_dev;
    board->Calibration.mode = 0;
    board->xyz.x = board->xyz.y = board->xyz.z = 0;

    for (p = 0; p< MAX_ACTIV_TOUCHES_PER_BOARD; p++)
        board->Touch.Last[p].TrackingID = -1;
    board->Touch.RadiusUnit = 300;

    if (dev->manufacturer)
        strlcpy(board->name, dev->manufacturer, sizeof(board->name));

    if (dev->product) {
        if (dev->manufacturer)
            strlcat(board->name, " ", sizeof(board->name));

        strlcat(board->name, dev->product, sizeof(board->name));
    }

    board->idProduct = dev->descriptor.idProduct;
    switch (dev->descriptor.idProduct)
    {
    case 4: // AC3
    case 5: // Slate60
        board->DelayWrites = 3;
        break;
    case 1: // ac1 / ac2
    case 2: // activhub
        board->xyz.z = MAX_PRESSURE_LEVELS + 1; // boards than do not support pressure: send max pressure on first coord
        board->DelayWrites = 25;
        break;
    case 3: // activhub 2.4
    default:
        board->xyz.z = MAX_PRESSURE_LEVELS + 1; // boards than do not support pressure: send max pressure on first coord
        board->DelayWrites = 3;
        break;
    }

    DebugPrint(TRACE_LEVEL_RELEASE,DRV_DBG_INIT,(KERN_INFO "Promethean: This device delay writes by %d ms.\n",(int)board->DelayWrites));

    if (!strlen(board->name))
        snprintf(board->name, sizeof(board->name),
                 "USB ACTIVboard  %04x:%04x",
                 le16_to_cpu(dev->descriptor.idVendor),
                 le16_to_cpu(dev->descriptor.idProduct));

    usb_make_path(dev, board->phys, sizeof(board->phys));
    strlcat(board->phys, "/input0", sizeof(board->phys));

    sema_init(&board->limit_sem,1);
    sema_init(&board->list_sem,1);
    sema_init(&board->xinput_sem,1);
    sema_init(&board->endpoint_initialise_sem,1);
    sema_init(&board->data_processor_sem,1);
    sema_init(&board->PrivateData.mtx,1);

    for (p = 0; p < inpipe_count; p++) {
        sema_init(&board->input_data_ready[p],0);
        //mutex_lock(&board->input_data_ready[p]);

        sema_init(&board->input_data_thread_end[p],0);
        //mutex_lock(&board->input_data_thread_end[p]);

        board->in_processing_threads[p] = kthread_run(usb_activ_thread_process_pipe_data, board->irq[p],"Input [%d]",p);
    }

    if (input_dev)
    {
        input_dev->name = board->name;
        input_dev->phys = board->phys;

        usb_to_input_id(dev, &input_dev->id);
#if (LINUX_VERSION_CODE < KERNEL_VERSION(2,6,25))
        input_dev->cdev.dev = &intf->dev;
#endif

        set_bit(EV_KEY,input_dev->evbit);
        set_bit(EV_ABS,input_dev->evbit);
        set_bit(ABS_X,input_dev->absbit);
        set_bit(ABS_Y,input_dev->absbit);
        //set_bit(ABS_MT_POSITION_X,input_dev->absbit);
        //set_bit(ABS_MT_POSITION_Y,input_dev->absbit);
        //set_bit(ABS_PRESSURE,input_dev->absbit);
        set_bit(BTN_LEFT,input_dev->keybit);
        set_bit(BTN_MIDDLE,input_dev->keybit);
        set_bit(BTN_RIGHT,input_dev->keybit);
        set_bit(BTN_TOOL_PEN,input_dev->keybit);

        /* necessary otherwise we get detected as a joystick (some udev rule on Debian / Ub) */
        set_bit(BTN_TOOL_FINGER,input_dev->keybit);

        //input_set_abs_params(input_dev, ABS_PRESSURE, 0, MAX_PRESSURE_LEVELS, 0, 0);
        input_set_abs_params(input_dev, ABS_X, 0, 32767, 0, 0);
        input_set_abs_params(input_dev, ABS_Y,  0, 32767,0, 0);
#if USE_MT_API
        input_mt_init_slots(input_dev, MAX_SLOTS);
        input_set_events_per_packet(input_dev, 80);
        input_set_abs_params(input_dev, ABS_MT_TRACKING_ID, 0, MAX_TRACKING_ID, 0, 0);
        input_set_abs_params(input_dev, ABS_MT_POSITION_X, 0, 32767, 2, 0);
        input_set_abs_params(input_dev, ABS_MT_POSITION_Y,  0, 32767,2, 0);
        input_set_abs_params(input_dev, ABS_MT_TOUCH_MAJOR,  0, (0x7 * board->Touch.RadiusUnit), 0, 0);
#endif

#ifdef _PRE_2_6_18_
        input_dev->private = board;
#else
        input_set_drvdata(input_dev, (void*)board);
#endif
        input_dev->open = usb_activ_xinput_activ_open;
        input_dev->close = usb_activ_xinput_activ_close;

        if (input_register_device(board->x11dev))
        {
            DebugPrint(TRACE_LEVEL_CRITICAL,DRV_DBG_INIT, (KERN_ALERT "Promethean: input_register_device failed. abort.\n"));
            goto fail;
        }

        usb_activ_reset_calibration(board);
    }

    usb_set_intfdata(intf, board);

    retval = usb_register_dev(intf, &usb_activ_file_class);

    if (retval) {
        DebugPrint(TRACE_LEVEL_CRITICAL,DRV_DBG_INIT, (KERN_ALERT "Promethean: Not able to get a minor for this device.\n"));
        usb_set_intfdata(intf, NULL);
        goto fail;
    }


    return 0;

fail:
    for (p = 0; p < MAX_INT_PIPES; p++) {
        if (board->data_in[p])
            usb_free_coherent(dev, maxp, board->data_in[p], board->data_in_dma[p]);
    }

    if (input_dev)
        input_free_device(input_dev);

    if (board)
        kfree(board);

    printk(KERN_INFO "Promethean: Error when initialising\n");

    return -ENOMEM;
}

/*
* usb_activ_disconnect: called when device is disconnected. Clean up active urbs, close open files, memory cleanup.
*/
static void usb_activ_disconnect(struct usb_interface *intf)
{
    struct usb_activ_device *board = usb_get_intfdata (intf);
    int p = 0;

    DebugPrint(TRACE_LEVEL_VERBOSE,DRV_DBG_INIT,(KERN_INFO "Promethean: %s : %s : disconnect.\n", DRIVER_VERSION, DRIVER_DESC));

    usb_set_intfdata(intf, NULL);
    usb_deregister_dev(intf, &usb_activ_file_class);

    if (board) {

        for (p = 0; p < MAX_INT_PIPES; p++) {
            if (board->irq[p])
                usb_kill_urb(board->irq[p]);
        }



        if (board->write_urb)
        {

            usb_kill_urb(board->write_urb);
        }

        if (board->data_list_head) {
            usb_activ_stop_files(board);
        }

        if (board->x11dev)
            input_unregister_device(board->x11dev);

        for (p = 0; p < MAX_INT_PIPES; p++) {

            if (board->irq[p]) {

                usb_free_urb(board->irq[p]);
                board->irq[p] = NULL;

                up(&board->input_data_ready[p]);
                if (down_interruptible(&board->input_data_thread_end[p]))
                {
                    DebugPrint(TRACE_LEVEL_CRITICAL,DRV_DBG_THREADS,("Promethean: #Warning: Could not signal the input data thread semaphore."));
                }

                /* wait for board to finish */

                usb_free_coherent(interface_to_usbdev(intf), board->maxp, board->data_in[p], board->data_in_dma[p]);
            }
        }

        kfree(board);
    }

    DebugPrint(TRACE_LEVEL_RELEASE,DRV_DBG_INIT,(KERN_INFO "Promethean: disconnected.\n"));
}

static int usb_activ_suspend(struct usb_interface *intf, pm_message_t state)
{
    struct usb_activ_device *board = usb_get_intfdata (intf);


    DebugPrint(TRACE_LEVEL_RELEASE,DRV_DBG_INIT,(KERN_INFO "Promethean: %s : %s : Suspend.\n", DRIVER_VERSION, DRIVER_DESC));
    if (board)
    {
        // make sure we are in idle if we are a hub
        if (board->HubState != 0)
        {
            DebugPrint(TRACE_LEVEL_RELEASE,DRV_DBG_INIT,(KERN_INFO "Promethean: %s : %s : Suspend cancelled: Hub state 0x%x.\n", DRIVER_VERSION, DRIVER_DESC,board->HubState));
            return -1;
        }

        usb_activ_write(board,":PW0\r",5,FALSE, TRUE);
        usb_activ_xinput_open_mode(board, X11_CLOSED);
        board->initialised = FALSE;

    }

    return 0;
}

static int usb_activ_resume(struct usb_interface *intf)
{
    /* On later kernels, resume is called, then nothing. On earlier, we get re-enumerated. Probably something
to do with udev. */
    struct usb_activ_device *board = usb_get_intfdata (intf);

    DebugPrint(TRACE_LEVEL_RELEASE,DRV_DBG_INIT,(KERN_INFO "Promethean: %s : %s : Resume.\n", DRIVER_VERSION, DRIVER_DESC));
#if (LINUX_VERSION_CODE > KERNEL_VERSION(2,6,30))
    if (board)
    {
        int p = 0;
        for (p = 0; p < MAX_INT_PIPES ; p++) {
            if (board->irq[p]) {
                board->irq[p]->dev = board->usbdev;

                usb_activ_reset_endpoint(board,board->pipe_in[p]);

                if (usb_submit_urb(board->irq[p], GFP_KERNEL))
                    break;
            }
        }
        usb_activ_write(board,":PW1\r",5,FALSE, TRUE);
    }
#endif
    return 0;
}

/* list of devices we support */
static struct usb_device_id usb_activ_id_table [] =
{
    { USB_DEVICE(0x0d48,0x0001) },			/* USB ActivBoard / ActivHub */
    { USB_DEVICE(0x0d48,0x0003)	},			/* USB 2.4 gHz hub */
    { USB_DEVICE(0x0d48,0x0004)	},			/* USB AC3 */
    { USB_DEVICE(0x0d48,0x0005)	},			/* USB Slate 60 */
    { USB_DEVICE(0x0d48,0x0006)	},			/* USB Project X */
    { }						/* Terminating entry */
};

MODULE_DEVICE_TABLE (usb, usb_activ_id_table);

static struct usb_driver usb_activ_driver =
{
    .name		= "Promethean ActivDriver",
    .probe		= usb_activ_probe,
    .disconnect	= usb_activ_disconnect,
    .suspend	= usb_activ_suspend,
    .resume		= usb_activ_resume,
    .id_table	= usb_activ_id_table,
};

/*
* usb_activ_init: driver entry point.
*/
static int __init usb_activ_init(void)
{
    int retval = usb_register(&usb_activ_driver);

    if (retval == 0)
    {
        DebugPrint(TRACE_LEVEL_CRITICAL,DRV_DBG_INIT,(KERN_INFO DRIVER_VERSION ":" DRIVER_DESC));
    }
    return retval;
}

/*
* usb_activ_exit: driver exit point.
*/
static void __exit usb_activ_exit(void)
{
    DebugPrint(TRACE_LEVEL_CRITICAL,DRV_DBG_INIT,(KERN_INFO "Promethean:  exit.\n"));
    usb_deregister(&usb_activ_driver);
}

module_init(usb_activ_init);
module_exit(usb_activ_exit);


int isLeft(calibration_point *p0, calibration_point *p1, int xraw, int yraw)
{
    return (p1->x - p0->x) * (yraw - p0->y) - (xraw - p0->x) * (p1->y - p0->y);
}

bool ptInPolygon(int xraw, int yraw, calibration_point points[5])
{
    long wn = 0;
    int p = 0;

    for (p = 0; p < 4; p++)
    {
        if (points[p].y <= yraw)
        {
            if (points[p+1].y > yraw)
                if (isLeft(&points[p], &points[p+1], xraw, yraw) > 0)
                    wn++;
        }
        else
        {
            if (points[p+1].y <= yraw)
                if (isLeft(&points[p], &points[p+1], xraw, yraw) < 0)
                    wn--;
        }
    }
    return  wn != 0;
}


int selectQuad(int* xraw, int* yraw, unsigned char matrix_size, calibration_quad_region *quads)
{
    int q = 0;

    for (q = 0; q < matrix_size; q++)
    {
        int xtest = *xraw - quads[q].raw_min.x;
        int ytest = *yraw - quads[q].raw_min.y;

        if (ptInPolygon(xtest, ytest, quads[q].raw_points))
        {
            *xraw = xtest;
            *yraw = ytest;
            return q;
        }
    }


    for (q = 0; q < matrix_size; q++)
    {
        if ((*xraw >= quads[q].hit_rect.left)
                && (*xraw < quads[q].hit_rect.right)
                && (*yraw >= quads[q].hit_rect.top)
                && (*yraw < quads[q].hit_rect.bottom))
        {
            *xraw = *xraw - quads[q].raw_min.x;
            *yraw = *yraw - quads[q].raw_min.y;

            return q;
        }
    }

    DebugPrint(TRACE_LEVEL_INFORMATION,
               DRV_DBG_BOARD_DATA,
               (KERN_INFO "Promethean: Unknown Quad %d %d %d\n", *xraw, *yraw, matrix_size));

    return -1;
}

u8 transformToRect(int xraw, int yraw,
                   unsigned short *x, unsigned short *y,
                   calibration_quad_region* quad)
{
    s64 w, a, b, s = 1;
    int nx, ny;
    calibration_matrix *m = &quad->matrix;
    calibration_rect   *r = &quad->display_rect;
    const u16 screen_width = (u16)(quad->screen_rect.right - quad->screen_rect.left + 1),
            screen_height = (u16)(quad->screen_rect.bottom - quad->screen_rect.top + 1);
    // do the maths as s64 and cast back to long
    w = m->m13 * xraw + m->m23 * yraw + m->m33;
    if (!w)
        return FALSE;

    *x = (u16)quad->screen_rect.left, *y = (u16)quad->screen_rect.top;

    a = (s64)(m->m11 * xraw + m->m21 * yraw + m->dx) * SCALE_FACTOR[1];
    if (a < 0)
		s = -1;
		
	a = a * s;
	do_div(a, w);
	b = (s64)(r->right - r->left+1) * a;
	do_div(b, SCALE_FACTOR[1]);
	b = b * s;
    
    nx = (int)(r->left + b);
    if (nx > screen_width)
        nx = screen_width;
    if (nx > 0)
        *x = (unsigned short) nx;
	
	a = (s64)(m->m22 * yraw + m->m12 * xraw + m->dy) * SCALE_FACTOR[1];
    s = 1;
    if (a < 0)
		s = -1;
	a = a * s;
	do_div(a, w);
	b = (s64)(r->bottom - r->top + 1) * a;
	do_div(b, SCALE_FACTOR[1]);
	b = b * s;
	
    ny = (int)(r->top + b);
    if (ny > screen_height)
        ny = screen_height;
    if (ny > 0)
        *y = (unsigned short) ny;


    DebugPrint(TRACE_LEVEL_VERBOSE,
               DRV_DBG_BOARD_DATA,
               (KERN_INFO "Promethean: raw nx ny (%d,%d)\n",nx,ny));
    return TRUE;
}

u8 CalibrateEx(u16 xraw, u16 yraw,
               u16 *x, u16 *y,
               u8 w, u8 h,
               calibration_quad_region* quads,u8 slate)
{
    DebugPrint(TRACE_LEVEL_VERBOSE,
               DRV_DBG_BOARD_DATA,
               (KERN_INFO "Promethean: In Coords  x,y (%d,%d)\n",xraw,yraw));

    if (slate)
    {
        // slate is reversed, and always 12000 to 8800
        const int max_width = 12000, max_height = 8800;

        // this is screen relative, it gets converted to desktop before sending to windows.
        *x = (xraw * MAX_MOUSE_RANGE) / max_width;
        *y = ((max_height - yraw) * MAX_MOUSE_RANGE) / max_height;
    }
    else
    {
        int nx = xraw, ny = 12000 - yraw;
        u16 xt = 0, yt = 0;
        int q = selectQuad(&nx, &ny, w * h, quads);
        if (q < 0)
            return FALSE;

        if (!transformToRect(nx, ny, x, y, &quads[q]))
            return FALSE;

        if ((w > 1)  && (h > 1))
        {
            if (*x <= (quads[q].display_rect.left + 1))
            {
                if (q % w)
                {
                    nx = xraw, ny = 12000 - yraw;
                    nx = nx - quads[q-1].raw_min.x;
                    ny = ny - quads[q-1].raw_min.y;

                    if (transformToRect(nx, ny, &xt, &yt, &quads[q-1]))
                    {
                        DebugPrint(TRACE_LEVEL_VERBOSE,
                                   DRV_DBG_BOARD_DATA,
                                   (KERN_INFO "Promethean: averaging with quad on left %d,%d %d,%d\n",*x,*y,xt,yt));

                        *x = (u16)(((int)*x + xt) / 2);
                        *y = (u16)(((int)*y + yt) / 2);
                    }
                }
            }

            if (*y <= (quads[q].display_rect.top + 1))
            {
                if (q / h)
                {
                    nx = xraw, ny = 12000 - yraw;
                    nx = nx - quads[q-w].raw_min.x;
                    ny = ny - quads[q-w].raw_min.y;

                    if (transformToRect(nx, ny, &xt, &yt, &quads[q-w]))
                    {
                        DebugPrint(TRACE_LEVEL_VERBOSE,
                                   DRV_DBG_BOARD_DATA,
                                   (KERN_INFO "Promethean: averaging with quad above %d,%d %d,%d\n",*x,*y,xt,yt));

                        *x = (u16)(((int)*x + xt) / 2);
                        *y = (u16)(((int)*y + yt) / 2);
                    }
                }
            }

            if (*x >= (quads[q].display_rect.right - 1))
            {
                if ((q % w) != (w-1))
                {
                    nx = xraw, ny = 12000 - yraw;
                    nx = nx - quads[q+1].raw_min.x;
                    ny = ny - quads[q+1].raw_min.y;

                    if (transformToRect(nx, ny, &xt, &yt, &quads[q+1]))
                    {
                        DebugPrint(TRACE_LEVEL_VERBOSE,
                                   DRV_DBG_BOARD_DATA,
                                   (KERN_INFO "Promethean: averaging with quad on right %d,%d %d,%d\n",*x,*y,xt,yt));

                        *x = (u16)(((int)*x + xt) / 2);
                        *y = (u16)(((int)*y + yt) / 2);
                    }
                }
            }

            if (*y >= (quads[q].display_rect.bottom - 1))
            {
                if ((q / h) != (h-1))
                {
                    nx = xraw, ny = 12000 - yraw;
                    nx = nx - quads[q+w].raw_min.x;
                    ny = ny - quads[q+w].raw_min.y;

                    if (transformToRect(nx, ny, &xt, &yt, &quads[q+w]))
                    {
                        DebugPrint(TRACE_LEVEL_VERBOSE,
                                   DRV_DBG_BOARD_DATA,
                                   (KERN_INFO "Promethean: averaging with quad below %d,%d %d,%d\n",*x,*y,xt,yt));

                        *x = (u16)(((int)*x + xt) / 2);
                        *y = (u16)(((int)*y + yt) / 2);
                    }
                }
            }
        }


        DebugPrint(TRACE_LEVEL_VERBOSE,
                   DRV_DBG_BOARD_DATA,
                   (KERN_INFO "Promethean: Pixel Coords Quad is %d x,y (%d,%d)\n",q,*x,*y));

        // screen relative in pixel to max_mouse_range desktop relative
        if (quads[q].desktop_size.x)
            *x = (unsigned short)((*x + quads[q].screen_rect.left) * MAX_MOUSE_RANGE / quads[q].desktop_size.x);

        if (quads[q].desktop_size.y)
            *y = (unsigned short)((*y + quads[q].screen_rect.top) * MAX_MOUSE_RANGE / quads[q].desktop_size.y);

        DebugPrint(TRACE_LEVEL_VERBOSE,
                   DRV_DBG_BOARD_DATA,
                   (KERN_INFO "Promethean: MMR Coords Quad is %d x,y (%d,%d)\n",q,*x,*y));
    }

    return TRUE;
}

