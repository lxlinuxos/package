/*
 *  Copyright 2006 - 2007 Promethean Ltd
 *  Promethean ActivBoard/ActivHub USB Driver
 */

/*
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */

#ifndef _USBPROMETHEAN_H
#define _USBPROMETHEAN_H

/*
 * Generic definitions.
 */

#define TRUE 	1
#define FALSE 	0

#include <linux/kernel.h>
#include <linux/version.h>

#include "../inc/linux/decls.h"
#include "../inc/activcalibration.h"


/*
 * Calibration
 */
void if4vectormul(int rO, long *vO, int rA, long mA[4][4], int rI, long *vI);
void ifhomogenize(int dim, int r, long *v);
int bboxclip(long *bbox, long *p);
int cvvclip(int r, long *p, long accy);
void cvvproject(int r, long *p);
void format(long *outrect,int rOutrect,int rNorm,long *out4,long *out);
void formatex(long *outrect,int rOutrect,int rNorm,long *wndrect,long *desktoprect,long *out4,long *out,unsigned char);
long round(long r, long x);
long convert(long _nr, long _or, long x);
long IMulDiv32(long aa, long ab, long ac);
long powe (long base,int power);
long absol(long x);
long scale(long a,long b,long c);

#endif
