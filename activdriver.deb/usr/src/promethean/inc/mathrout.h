#ifndef _MATHROUT_INCLUDED_
#define _MATHROUT_INCLUDED_

void ifhomogenize(int dim, int r, long *v);
void if4vectormul(int rO, long *vO, int rA, long mA[4][4], int rI, long *vI);
int bboxclip(long *bbox, long *p);
int cvvclip(int r, long *p, long accy);
void cvvproject(int r, long *p);
void format(long *outrect,int rOutrect,int rNorm,long *out4,long *out);
void formatex(long *outrect,int rOutrect,int rNorm,long *wndrect,long *desktoprect,long *out4,long *out,BOOLEAN);
long round(long r, long x);
long convert(long _nr, long _or, long x);
long IMulDiv32(long aa, long ab, long ac);
long powe (long base,int power);
long absol(long x);
long scale(long a,long b,long c);

#endif