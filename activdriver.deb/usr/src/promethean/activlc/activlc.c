#include <stdio.h>
#include <fcntl.h>
#include <string.h>
#include <errno.h>
#include <getopt.h>
#include <sys/ioctl.h>
#include <sys/stat.h>
#include <semaphore.h>

#include <linux/activioctl.h>

#include <sys/types.h>
#include <sys/uio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>

sem_t *sem = NULL;
void unlock();

#include <signal.h>
void termination_handler (int signum)
{
    unlock();
    _exit(-1);
}

// load calibration on board (not in memory)
int LoadCalibration(const char *szDevice)
{
    int board_descriptor = -1;
    int f = -1;
    char szFile[256] = {"Unknown"};
    char szFilev2[256] = {"Unknown"};
    unsigned char data[20];
    int retval = 0, nread = 0;
    const int TimeoutMS = 5000;

    printf("Promethean: Opening calibration for device %s\n",szDevice);
    board_descriptor = open(szDevice,O_RDWR);
    if (board_descriptor < 0)
    {
        perror("Error opening ACTIVBoard: ");
        return -1;
    }

    if (!ioctl(board_descriptor,ACTIV_SET_TIMEOUT,&TimeoutMS))
    {
        // send :Q1 to identify the device
        unsigned char identified = 0, type = 0;
        int retries = 0;

        while ((!identified) && (++retries < 10))
        {
            ioctl(board_descriptor,ACTIV_FLUSH_QUEUE,NULL);
            write(board_descriptor,":Q1\r",4);
            memset(data,0,sizeof(data));
            identified = 0;
            type = 0;


            if (read(board_descriptor,data,20) < 0)
                break;

            do
            {
                if (data[1] == 0x77)
                    --retries;
                else
                    if ((data[1] == 0x32) && (!type))
                        type = (unsigned char)atoi((char*)data+5);

                printf("Promethean: Device type %x\n",type);
                switch (type)
                {
                case 3:
                case 4:
                case 7:
                case 8:

                    memset(data,0,sizeof(data));
                    identified = 0;
                    write(board_descriptor,":SN\r",4);
                    nread = read(board_descriptor,data,20);
                    printf("Promethean: Received %d bytes from :SN\n",nread);
                    printf("Promethean: 0x%02x 0x%02x\n",data[0],data[1]);

                    if (nread >= 0)
                    {
                        switch (data[1])
                        {
                        case 0x77:
                        case 0x32:
                            retries--;
                            break;

                        case 0x69:
                        {
                            identified = 1;
                            switch (type)
                            {
                            case 8:
                                if (data[2] + data[3] + data[4] + data[5])
                                {
                                    sprintf(szFile,"/etc/promethean/calibration/calibrate-%02x%02x%02x%02x%02x%02x.data",
                                            data[7],data[6],
                                            data[2],data[3],data[4],data[5]);
                                    sprintf(szFilev2,"/etc/promethean/calibration/calibratev2-%02x%02x%02x%02x%02x%02x.data",
                                            data[7],data[6],
                                            data[2],data[3],data[4],data[5]);
                                }
                                else
                                {
                                    identified = 0;
                                }
                                break;
                            default:
                                sprintf(szFile,"/etc/promethean/calibration/calibrate-%02x%02x%02x%02x%02x%02x.data",
                                        data[7],data[6],
                                        data[5],data[4],data[3],data[2]);
                                sprintf(szFilev2,"/etc/promethean/calibration/calibratev2-%02x%02x%02x%02x%02x%02x.data",
                                        data[7],data[6],
                                        data[5],data[4],data[3],data[2]);
                                break;
                            }
                        }
                        }
                    }
                    break;
                case 5:
                    memset(data,0,sizeof(data));
                    write(board_descriptor,":HI\r",4);
                    nread = read(board_descriptor,data,20);

                    printf("Promethean: Received %d bytes from :HI\n",nread);
                    printf("Promethean: 0x%02x 0x%02x\n",data[0],data[1]);
                    identified = 0;

                    if (nread >= 0)
                    {
                        if (data[1] == 0x77)
                        {
                            identified = 1;
                            sprintf(szFile,"/etc/promethean/calibration/calibrate-000000%02x%02x%02x.data",
                                    data[2],data[3],data[4]);
                            sprintf(szFilev2,"/etc/promethean/calibration/calibratev2-000000%02x%02x%02x.data",
                                    data[2],data[3],data[4]);
                        }
                    }
                    break;
                case 0xe:
                case 0xd:
                    retval = -3;
                    retries = 10;
                    identified=0;
                    break;
                default:
                    fprintf(stderr,"Promethean: (activlc) Invalid device type.");
                    retval = -2;
                    identified = 0;
                    break;

                }
            } while ((!identified) && (read(board_descriptor,data,20) > 0));

            if (!identified)
                usleep(500000 * ((retries % 2) +1));
        }

        if (identified)
        {
            struct stat sb;

            memset(&sb,0,sizeof(sb));
            if (!stat(szFilev2, &sb)) // v2 exists: use it
                strcpy(szFile,szFilev2);

            memset(&sb,0,sizeof(sb));
            if (!stat(szFile, &sb))
            {
                // open the calibration file. This should succeed, the stat was ok, but you may have read issues.
                f = open(szFile,O_RDONLY);

                if (f >= 0)
                {
                    int read_size = 0;
                    unsigned char *data = (unsigned char*)malloc(sb.st_size); // size in 152 in 32 bit and 304 in 64 bit

                    if (data)
                    {
                        read_size = read(f, data, sb.st_size);
                        close(f);

                        if (read_size > 10)
                        {
                            if (!memcmp(data, "QUADS", 5))
                            {
                                quad_data_t qdata;
                                int q;

                                qdata.width = data[5];
                                qdata.height = data[6];

                                // make sure the data is the right size
                                if (read_size == ((qdata.width * qdata.height) * sizeof(calibration_quad_region) + 7))
                                {
                                    for (q = 0; q < (qdata.width * qdata.height); q++)
                                    {
                                        qdata.ndx = (unsigned char)q;
                                        memcpy(&qdata.quad, data + 7 + q * sizeof(calibration_quad_region),sizeof(calibration_quad_region));
                                        ioctl(board_descriptor,ACTIV_SET_CALIBRATION_DATA_EX,&qdata);

                                    }
                                    qdata.ndx = 0xff;
                                    if (ioctl(board_descriptor,ACTIV_SET_CALIBRATION_DATA_EX,&qdata))
                                    {
                                        perror("Promethean: Error loading calibration (v2)");
                                        retval = -4;
                                    }

                                }
                                else
                                {
                                    perror("Promethean: Invalid data size (v2)");
                                    retval = -5;
                                }
                            }
                            else
                                if (read_size == sizeof(CALIB_DATA))
                                {
                                    int io = ioctl(board_descriptor,ACTIV_SET_CALIBRATION_DATA,data);
                                    if (io)
                                    {
                                        perror("Promethean: Error loading calibration (v1)");
                                        retval = -4;
                                    }
                                }
                                else
                                {
                                    fprintf(stderr, "Promethean: Invalid data size (v1)");
                                    retval = -5;
                                }
                        }
                        else
                        {
                            fprintf(stderr, "Promethean: Invalid data");
                            retval = -5;
                        }

                        free(data);
                    }
                    else
                    {
                        fprintf(stderr, "Promethean: Error allocating data");
                        retval = -3;
                    }
                }
                else
                {
                    perror("Promethean: Error opening file");
                    retval = -3;
                }
            }
            else
            {
                perror("Promethean: Error accessing file");
                retval = -3;
            }
        }
        else
        {
            fprintf(stderr,"Promethean: Cannot identify device.");
            retval = -6;
        }

    }
    else
    {
        fprintf(stderr,"Promethean: Cannot set timeout.");
        retval = -7;
    }

    close(board_descriptor);
    return retval;
}

int processArgs( int argc, char **argv )
{
    int ch;
    /* options descriptor */
    static struct option longopts[] = {
        { "load",      1,      NULL,           'l' },
        { NULL,         0,                      NULL,           0 }
    };


    // when plugging boards, all devices get loaded with --load ... --device ...
    // this takes precedence over the normal device detection.

    // cmd line args return straight away
    while ((ch = getopt_long(argc, argv, "l:", longopts, NULL)) != -1)
    {
        switch (ch)
        {
        case 'l':
            if (optarg)
                return LoadCalibration(optarg);
            break;
        }
    }

    return -1;
}

int lock()
{
    int ret = -1;
    umask(0);
    sem = sem_open("activlc",O_CREAT,0666,1);

    if (sem)
    {
        if (sem_trywait(sem) < 0)
        {
            usleep(15000 * 1000);
            if (sem)
                if (sem_trywait(sem) >= 0)
                    ret = 0;
        }
        else
            ret = 0;
    }

    if (ret < 0)
        sem_unlink("activlc");
    return ret;
}

void unlock()
{
    if (sem)
    {
        sem_post(sem);
        sem_close(sem);
    }
    sem_unlink("activlc");
    sem = NULL;
}

int main( int argc, char **argv )
{
    int ret = -1;

    struct sigaction new_action, old_action;

    /* Set up the structure to specify the new action. */
    new_action.sa_handler = termination_handler;
    sigemptyset (&new_action.sa_mask);
    new_action.sa_flags = 0;

    sigaction (SIGINT, NULL, &old_action);
    if (old_action.sa_handler != SIG_IGN)
        sigaction (SIGINT, &new_action, NULL);
    sigaction (SIGHUP, NULL, &old_action);
    if (old_action.sa_handler != SIG_IGN)
        sigaction (SIGHUP, &new_action, NULL);
    sigaction (SIGTERM, NULL, &old_action);
    if (old_action.sa_handler != SIG_IGN)
        sigaction (SIGTERM, &new_action, NULL);

    if (lock() == 0)
    {
        ret = processArgs(argc,argv);
        unlock();
    }

    return ret;
}
