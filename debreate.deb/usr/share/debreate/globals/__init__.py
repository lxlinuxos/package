# -*- coding: utf-8 -*-

## \package globals
