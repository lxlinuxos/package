#!/bin/bash


	#######################LANGUAGE######################
	LOCALDIR="/opt/lxlinux/software/locale"
	if [ "`cat /etc/default/locale | grep LANG= | grep es`" != "" ]; then
	. $LOCALDIR/es
	elif [ "`cat /etc/default/locale | grep LANG= | grep fr`" != "" ]; then
	. $LOCALDIR/fr
	elif [ "`cat /etc/default/locale | grep LANG= | grep pt_PT`" != "" ]; then
	. $LOCALDIR/pt_PT
	else
	. $LOCALDIR/en
	fi
	######################################################
	USER=$(whoami)
	STORE="/opt/lxlinux/software/script/store"
	if test $USER = "root"
	then
	if $STORE --title " " --question --skip-taskbar \
		--window-icon=/opt/lxlinux/software/icons/question.svg \
		--timeout=25 --timeout-indicator=bottom \
		--text "$E1" --fixed --center --text-align="center" \
		--button="$B4":0 --button="$B3":1
		then
	cp /opt/lxlinux/software/sources/lliurex-bionic-sources.list /etc/apt/sources.list && xterm -e apt update
		else
			$STORE --title " " --info --text "$E2" \
			--window-icon=/opt/lxlinux/software/icons/cancel.svg \
			--skip-taskbar --timeout=10 --timeout-indicator=bottom  --fixed \
			--center --text-align="center" --button=$B1:1
			exit 0
	fi
	else
		$STORE --title " " \
		--skip-taskbar --timeout=10 --timeout-indicator=bottom --fixed \
		--info --text "$D22" \
		--window-icon=/opt/lxlinux/software/icons/cancel.svg \
		--center --justify="center" --text-align="center" --button=$B1:1
	fi