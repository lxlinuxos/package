#!/bin/bash
xterm "apt-get install -f"