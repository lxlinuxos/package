#!/bin/sh
(
/opt/lxlinux/software/gsu apt-get install curl;
) |
yad --progress \
  --on-top \
  --height=100 \
  --width=400 \
  --title="Curl" \
  --text="Running installation" \
  --window-icon system-software-install \
  --center \
  --pulsate \
  --auto-close --auto-kill \
  --no-buttons
exit 0