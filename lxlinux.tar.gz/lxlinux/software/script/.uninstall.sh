#!/bin/bash
USER=$(whoami)
APP=download
function SOFTWARE {
	(
	echo "Uninstallation will begin..."
	echo "Do not close the window until instructed, unless errors appear..."
	sleep 7
	echo "Updating repository."
	sudo apt-get update;
	sudo apt purge $APP -y;
	echo -e "\n\nThanks for waiting. \nYou can now close the window."
	) | yad --title "Software Installation" --text-info --tail --skip-taskbar \
		--window-icon system-software-install \
		--width="750" --height="400" --center --button=Exit:0
}

if test $USER = "root"
then
	if yad --title "Software Installation" --question --skip-taskbar \
		--window-icon system-software-install \
		--timeout=25 \
		--timeout-indicator=bottom \
		--text "Do you want to continue with the installation?" --width="350" --height="50" --center --text-align="center" \
		--button="Continue Installation":0 --button="Cancel":1
		then
			SOFTWARE
		else
			yad --title "Installation canceled" --info --text "\nYou have canceled the installation" --skip-taskbar \
			--window-icon system-software-install \
			--timeout=10 \
			--timeout-indicator=bottom \
			--center --text-align="center" --width="300" --height="50" --button=Exit:1
			exit 0
	fi
else
		yad --title "Software Installation" --skip-taskbar \
		--info --text "You do not have permission to run the program" \
		--window-icon system-software-install \
		--width="400" --height="100" --center --justify="center" --text-align="center"
fi
