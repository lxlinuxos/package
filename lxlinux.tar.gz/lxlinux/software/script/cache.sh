#!/bin/sh
(
apt-get clean && sudo apt-get autoclean
) |
yad --progress \
  --on-top \
  --height=100 \
  --width=400 \
  --title="Download manager Aria2" \
  --text="Running installation" \
  --window-icon system-software-install \
  --center \
  --pulsate \
  --auto-close --auto-kill \
  --no-buttons


exit 0