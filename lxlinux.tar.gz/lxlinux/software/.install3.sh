#!/bin/bash

	#######################LANGUAGE######################
	LOCALDIR="/opt/lxlinux/software/locale"
	if [ "`cat /etc/default/locale | grep LANG= | grep es`" != "" ]; then
	. $LOCALDIR/es
	elif [ "`cat /etc/default/locale | grep LANG= | grep fr`" != "" ]; then
	. $LOCALDIR/fr
	elif [ "`cat /etc/default/locale | grep LANG= | grep pt_PT`" != "" ]; then
	. $LOCALDIR/pt_PT
	else
	. $LOCALDIR/en
	fi
	######################################################
	USER=$(whoami)
	APP=download
	HTTP=link
	TEST=`echo $APP | cut -f1 -d'.'`
	export LC_ALL=C
	######################################################
	function SOFTWARE {
	(
	######################################################
	echo "$D1";
	echo "$D2";
	sleep 5;
	################# UPDATE REPOSITORY ##################
	echo -e "$D3";
	sudo apt-get update;
	################# CHECK PACKAGE ######################
	echo -e "$D4";
	sleep 5;
	apt-cache policy $TEST
	if dpkg-query -W -f'${db:Status-Abbrev}\n' $TEST 2>/dev/null \ | grep -q '^.i $';  
	then
	echo -e "$D5"
	else
	echo -e "$D6"
	fi
	sleep 5;
	export LC_ALL=$LANG;
	################# CHECK GDEBI #########################
	echo -e "$D7"
	if command -v gdebi > /dev/null; then
	echo "$D8"
	else
	echo "$D9"
	apt-get install -q -y gdebi
	if [ "$?" -ne "0" ]; then
	echo -e "$D10"
	echo "$D11"
	exit 1
	fi
	fi
	################# CHECK WGET ##########################
	echo -e "$D23"
	if command -v wget > /dev/null; then
	echo "$D24"
	else
	echo "$D25"
	apt-get install -q -y wget
	if [ "$?" -ne "0" ]; then
	echo -e "$D26"
	echo "$D11"
	exit 1
	fi
	fi
	########################################################
	cd /opt/lxlinux/software/temp;
	echo -e "$D17";
	sleep 5;
	wget -r -l3 -t1 -nd -N -np -A "$APP" $HTTP
	sudo chmod -Rv 777 /opt/lxlinux/software/temp;
	echo -e "$D18";
	sleep 2;
	sudo gdebi -n /opt/lxlinux/software/temp/*.deb;
	sudo rm -rf /opt/lxlinux/software/temp/*;
	echo -e "$D19"
	) | yad --title "$C0" --text-info --tail \
		--window-icon=/opt/lxlinux/software/icons/app-center.svg \
		--width="750" --height="400" --center --button=$B1:1
	}

	export LC_ALL=$LANG;

	if test $USER = "root"
	then
	if yad --title " " --question --skip-taskbar \
		--window-icon=/opt/lxlinux/software/icons/question.svg \
		--timeout=25 --timeout-indicator=bottom \
		--text "$D20" --fixed --center --text-align="center" \
		--button="$B4":0 --button="$B3":1
		then
			SOFTWARE
		else
			yad --title " " --info --text "$D21" \
			--window-icon=/opt/lxlinux/software/icons/cancel.svg \
			--skip-taskbar --timeout=10 --timeout-indicator=bottom  --fixed \
			--center --text-align="center" --button=$B1:1
			exit 0
	fi
	else
		yad --title " " \
		--skip-taskbar --timeout=10 --timeout-indicator=bottom --fixed \
		--info --text "$D22" \
		--window-icon=/opt/lxlinux/software/icons/cancel.svg \
		--center --justify="center" --text-align="center" --button=$B1:1
	fi
